/**
 * MISSION CONTROL HUD & UI CONTROLLER (ENHANCED)
 * Binary Hacks 4.0 - PS-07
 * Features:
 * - Real-time UTC/IST/Julian Date Clocks
 * - 3D Direction Heading & Flight Path Angle
 * - Atmospheric Re-entry Burnup Alert & Ground Splashdown Prediction
 * - Hypervelocity Collision & Kessler Breakup Simulation
 * - Earth Auto-Rotation Speed Toggle
 */

import { CONFIG } from './config.js';
import { OrbitalMath } from './orbital-math.js';
import { AIPredictor } from './ai-predictor.js';
import { spawnBreakupDebris } from './data-source.js';
import { audio } from './audio-fx.js';

export class UIController {
  constructor(appState) {
    this.app = appState;

    // Cache DOM Elements
    this.dom = {
      // Clocks & Header
      utcClock: document.getElementById('utc-clock'),
      istClock: document.getElementById('ist-clock'),
      jdClock: document.getElementById('jd-clock'),
      simSpeedLabel: document.getElementById('sim-speed-label'),
      alertBanner: document.getElementById('critical-alert-banner'),
      alertBannerText: document.getElementById('alert-banner-text'),
      btnAlertDismiss: document.getElementById('btn-alert-dismiss'),
      btnExecuteAvoidance: document.getElementById('btn-execute-avoidance'),

      // Atmospheric Re-entry Banner
      reentryBanner: document.getElementById('reentry-alert-banner'),
      reentryBannerText: document.getElementById('reentry-banner-text'),

      // Left Panel: Stats & Search
      statTotal: document.getElementById('stat-total'),
      statPayloads: document.getElementById('stat-payloads'),
      statRockets: document.getElementById('stat-rockets'),
      statDebris: document.getElementById('stat-debris'),
      searchInput: document.getElementById('search-input'),
      objectsListContainer: document.getElementById('objects-list'),

      // Right Panel: Target Telemetry
      telemetryPanel: document.getElementById('telemetry-panel'),
      targetName: document.getElementById('target-name'),
      targetNorad: document.getElementById('target-norad'),
      targetTypeBadge: document.getElementById('target-type-badge'),
      targetAgency: document.getElementById('target-agency'),
      valLat: document.getElementById('val-lat'),
      valLon: document.getElementById('val-lon'),
      valAlt: document.getElementById('val-alt'),
      valSpeedKmS: document.getElementById('val-speed-kms'),
      valSpeedKmH: document.getElementById('val-speed-kmh'),
      valSpeedMach: document.getElementById('val-speed-mach'),
      valSpeedLight: document.getElementById('val-speed-light'),
      valFlightPath: document.getElementById('val-flight-path'),
      valDirection: document.getElementById('val-direction'),
      valInc: document.getElementById('val-inc'),
      valEcc: document.getElementById('val-ecc'),
      valPeriod: document.getElementById('val-period'),
      valApogee: document.getElementById('val-apogee'),
      valPerigee: document.getElementById('val-perigee'),
      targetDescription: document.getElementById('target-description'),

      // Conjunction & AI Risk Section
      conjunctionSection: document.getElementById('conjunction-section'),
      threatObjName: document.getElementById('threat-obj-name'),
      threatMissDistance: document.getElementById('threat-miss-distance'),
      threatRelVelocity: document.getElementById('threat-rel-velocity'),
      threatProbability: document.getElementById('threat-probability'),
      threatTca: document.getElementById('threat-tca'),
      threatImpactEnergy: document.getElementById('threat-impact-energy'),
      threatRiskBadge: document.getElementById('threat-risk-badge'),

      // Kessler Matrix
      kesslerIndexVal: document.getElementById('kessler-index-val'),
      kesslerBar: document.getElementById('kessler-bar'),
      kesslerStatus: document.getElementById('kessler-status'),

      // Avoidance Maneuver Modal
      maneuverModal: document.getElementById('maneuver-modal'),
      maneuverDetails: document.getElementById('maneuver-details'),
      btnConfirmBurn: document.getElementById('btn-confirm-burn'),
      btnCloseModal: document.getElementById('btn-close-modal'),

      // Collision Explosion Modal
      explosionModal: document.getElementById('explosion-modal'),
      explosionDetails: document.getElementById('explosion-details'),
      btnCloseExplosionModal: document.getElementById('btn-close-explosion-modal'),

      // Controls
      btnSoundToggle: document.getElementById('btn-sound-toggle'),
      btnEarthSpinToggle: document.getElementById('btn-earth-spin-toggle'),
      btnEarthSpeedCycle: document.getElementById('btn-earth-speed-cycle'),
      btnToggleVectors: document.getElementById('btn-toggle-vectors'),
      btnToggleObjects: document.getElementById('btn-toggle-objects'),
      btnTriggerImpact: document.getElementById('btn-trigger-impact'),
      btnTelemetryCollision: document.getElementById('btn-telemetry-collision'),
      btnTelemetryTrack: document.getElementById('btn-telemetry-track'),
      btnDockSimulateCollision: document.getElementById('btn-dock-simulate-collision'),

      // Timetable & Multi-horizon Tabs and Radar
      tabCatalog: document.getElementById('tab-catalog'),
      tabTimetable: document.getElementById('tab-timetable'),
      viewCatalog: document.getElementById('view-catalog'),
      viewTimetable: document.getElementById('view-timetable'),
      timetableList: document.getElementById('collision-timetable-list'),
      timetableBadgeCount: document.getElementById('timetable-badge-count'),
      btnDockTimetable: document.getElementById('btn-dock-timetable'),
      proximityRadarList: document.getElementById('proximity-radar-list'),

      // Sidebars & Mode Switchers
      leftPanel: document.querySelector('.left-panel'),
      rightPanel: document.querySelector('.right-panel'),
      btnToggleLeftPane: document.getElementById('btn-toggle-left-pane'),
      btnToggleRightPane: document.getElementById('btn-toggle-right-pane'),
      handleLeftPane: document.getElementById('handle-left-pane'),
      handleRightPane: document.getElementById('handle-right-pane'),
      btnThemeToggle: document.getElementById('btn-theme-toggle'),
      btnMissionChandrayaan: document.getElementById('btn-mission-chandrayaan'),
      btnToggleAICopilot: document.getElementById('btn-toggle-ai-copilot'),

      // Non-Blocking Tactical Collision Alert Toast
      collisionAlertToast: document.getElementById('collision-alert-toast'),
      toastBody: document.getElementById('toast-body'),
      btnCloseToast: document.getElementById('btn-close-toast'),
      btnToastViewDossier: document.getElementById('btn-toast-view-dossier'),
      btnToastDismiss: document.getElementById('btn-toast-dismiss'),

      // Chandrayaan-4 HUD
      chandrayaanHud: document.getElementById('chandrayaan-hud'),
      btnAbortChandrayaan: document.getElementById('btn-abort-chandrayaan'),
      missionHudStatus: document.getElementById('mission-hud-status'),
      missionTeleAlt: document.getElementById('mission-tele-alt'),
      missionTeleVel: document.getElementById('mission-tele-vel'),
      missionTeleDist: document.getElementById('mission-tele-dist'),
      missionTeleFuel: document.getElementById('mission-tele-fuel')
    };

    this.forecastEvents = [];
    this.activeHorizonFilter = "ALL";
    this.activeFilterType = "ALL";
    this.searchQuery = "";
    this.currentConjunction = null;
    this.earthSpeeds = [
      { label: "0.25x (SLOW)", val: 0.3 },
      { label: "0.5x (CALM)", val: 0.65 },
      { label: "1x (STANDARD)", val: 1.0 },
      { label: "2x (FAST)", val: 2.0 },
      { label: "PAUSED", val: 0.0 }
    ];
    this.currentSpeedIdx = 1; // Default to 0.5x (Calm & realistic)

    this.setupEventListeners();
  }

  setupEventListeners() {
    // 1. Search Bar
    if (this.dom.searchInput) {
      this.dom.searchInput.addEventListener('input', (e) => {
        this.searchQuery = e.target.value.toLowerCase().trim();
        this.renderObjectsList();
      });
    }

    // 2. Filter Buttons
    document.querySelectorAll('.filter-chip').forEach(chip => {
      chip.addEventListener('click', (e) => {
        document.querySelectorAll('.filter-chip').forEach(c => c.classList.remove('active'));
        e.currentTarget.classList.add('active');
        this.activeFilterType = e.currentTarget.dataset.type;
        this.renderObjectsList();
        audio.playTargetLock();
      });
    });

    // 3. Time Warp Controls
    document.querySelectorAll('.btn-time-warp').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.btn-time-warp').forEach(b => b.classList.remove('active'));
        e.currentTarget.classList.add('active');
        const factor = parseInt(e.currentTarget.dataset.warp, 10);
        this.app.setTimeWarp(factor);
        if (this.dom.simSpeedLabel) {
          this.dom.simSpeedLabel.textContent = factor === 0 ? "PAUSED" : `${factor}x`;
        }
        audio.playTargetLock();
      });
    });

    // 4. Camera View Controls
    document.querySelectorAll('.btn-cam-view').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('.btn-cam-view').forEach(b => b.classList.remove('active'));
        e.currentTarget.classList.add('active');
        const view = e.currentTarget.dataset.view;
        this.app.earth3d.setCameraPreset(view);
        audio.playTargetLock();
      });
    });

    // 5. Earth Auto-Rotation Toggle
    if (this.dom.btnEarthSpinToggle) {
      this.dom.btnEarthSpinToggle.addEventListener('click', () => {
        this.app.earth3d.autoRotateEarth = !this.app.earth3d.autoRotateEarth;
        this.dom.btnEarthSpinToggle.innerHTML = this.app.earth3d.autoRotateEarth 
          ? `<span class="icon">🌍</span> EARTH SPIN: ON`
          : `<span class="icon">⏸️</span> EARTH SPIN: OFF`;
        this.dom.btnEarthSpinToggle.classList.toggle('active', this.app.earth3d.autoRotateEarth);
        audio.playTargetLock();
      });
    }

    // 5b. Earth Rotation Speed Adjustment Cycle
    if (this.dom.btnEarthSpeedCycle) {
      this.dom.btnEarthSpeedCycle.addEventListener('click', () => {
        this.currentSpeedIdx = (this.currentSpeedIdx + 1) % this.earthSpeeds.length;
        const speedObj = this.earthSpeeds[this.currentSpeedIdx];
        this.app.earth3d.setEarthSpinMultiplier(speedObj.val);
        this.dom.btnEarthSpeedCycle.innerHTML = `🌐 SPEED: ${speedObj.label}`;
        audio.playTargetLock();
      });
    }

    // 5c. Trajectory Direction Vectors Toggle (ON/OFF)
    if (this.dom.btnToggleVectors) {
      this.dom.btnToggleVectors.addEventListener('click', () => {
        const isShown = this.app.earth3d.toggleDirectionVectors();
        this.dom.btnToggleVectors.innerHTML = isShown 
          ? `🧭 VECTORS: ON` 
          : `🧭 VECTORS: OFF`;
        this.dom.btnToggleVectors.classList.toggle('active', isShown);
        audio.playTargetLock();
      });
    }

    // 5d. Objects Visibility Layer Toggle (ON/OFF)
    if (this.dom.btnToggleObjects) {
      this.dom.btnToggleObjects.addEventListener('click', () => {
        const isShown = this.app.earth3d.toggleAllObjects();
        this.dom.btnToggleObjects.innerHTML = isShown 
          ? `🛰️ OBJECTS: ON` 
          : `🛰️ OBJECTS: OFF`;
        this.dom.btnToggleObjects.classList.toggle('active', isShown);
        audio.playTargetLock();
      });
    }

    // 6. Sound Master Toggle
    if (this.dom.btnSoundToggle) {
      this.dom.btnSoundToggle.addEventListener('click', () => {
        const isMuted = audio.toggleMute();
        this.dom.btnSoundToggle.innerHTML = isMuted 
          ? `<span class="icon">🔇</span> AUDIO: OFF`
          : `<span class="icon">🔊</span> AUDIO: ON`;
        this.dom.btnSoundToggle.classList.toggle('muted', isMuted);
      });
    }

    // 7. Trigger Collision Impact Event Buttons
    if (this.dom.btnTriggerImpact) {
      this.dom.btnTriggerImpact.addEventListener('click', () => {
        this.simulateCollisionEvent();
      });
    }
    if (this.dom.btnTelemetryCollision) {
      this.dom.btnTelemetryCollision.addEventListener('click', () => {
        this.simulateCollisionEvent();
      });
    }
    if (this.dom.btnDockSimulateCollision) {
      this.dom.btnDockSimulateCollision.addEventListener('click', () => {
        this.simulateCollisionEvent();
      });
    }
    if (this.dom.btnTelemetryTrack) {
      this.dom.btnTelemetryTrack.addEventListener('click', () => {
        if (this.app.earth3d) {
          this.app.earth3d.setCameraPreset('follow');
        }
      });
    }

    // 8. Avoidance & Dismiss Buttons
    if (this.dom.btnExecuteAvoidance) {
      this.dom.btnExecuteAvoidance.addEventListener('click', () => {
        this.openAvoidanceModal();
      });
    }
    if (this.dom.btnAlertDismiss) {
      this.dom.btnAlertDismiss.addEventListener('click', () => {
        if (this.dom.alertBanner) this.dom.alertBanner.classList.add('hidden');
      });
    }
    if (this.dom.btnCloseModal) {
      this.dom.btnCloseModal.addEventListener('click', () => {
        if (this.dom.maneuverModal) this.dom.maneuverModal.classList.add('hidden');
      });
    }
    if (this.dom.btnConfirmBurn) {
      this.dom.btnConfirmBurn.addEventListener('click', () => {
        this.executeAvoidanceBurn();
      });
    }
    if (this.dom.btnCloseExplosionModal) {
      this.dom.btnCloseExplosionModal.addEventListener('click', () => {
        if (this.dom.explosionModal) this.dom.explosionModal.classList.add('hidden');
      });
    }

    // 9. Panel Tabs (Catalog vs Multi-Horizon Timetable)
    if (this.dom.tabCatalog) {
      this.dom.tabCatalog.addEventListener('click', () => {
        this.switchLeftTab('catalog');
      });
    }
    if (this.dom.tabTimetable) {
      this.dom.tabTimetable.addEventListener('click', () => {
        this.switchLeftTab('timetable');
      });
    }
    if (this.dom.btnDockTimetable) {
      this.dom.btnDockTimetable.addEventListener('click', () => {
        this.switchLeftTab('timetable');
      });
    }

    // 10. Multi-Horizon Filter Chips (ALL, 1h, 2h, 4h, 6h, 12h, 24h, 2d, 4d, 10d, 1m, 3m, 6m, 9m, 1y)
    document.querySelectorAll('.horizon-chip').forEach(chip => {
      chip.addEventListener('click', (e) => {
        document.querySelectorAll('.horizon-chip').forEach(c => c.classList.remove('active'));
        e.currentTarget.classList.add('active');
        this.activeHorizonFilter = e.currentTarget.dataset.horizon;
        this.renderTimetable();
        audio.playTargetLock();
      });
    });

    // 11. Collapsible Sidebar Panels & Floating Handles
    if (this.dom.btnToggleLeftPane) {
      this.dom.btnToggleLeftPane.addEventListener('click', () => this.toggleLeftPanel());
    }
    if (this.dom.handleLeftPane) {
      this.dom.handleLeftPane.addEventListener('click', () => this.toggleLeftPanel());
    }
    if (this.dom.btnToggleRightPane) {
      this.dom.btnToggleRightPane.addEventListener('click', () => this.toggleRightPanel());
    }
    if (this.dom.handleRightPane) {
      this.dom.handleRightPane.addEventListener('click', () => this.toggleRightPanel());
    }

    // Keyboard Shortcuts: '[' for Left Panel, ']' for Right Panel
    window.addEventListener('keydown', (e) => {
      if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
      if (e.key === '[') {
        this.toggleLeftPanel();
      } else if (e.key === ']') {
        this.toggleRightPanel();
      }
    });

    // 12. Theme Switcher (Light Mode / Dark Mode)
    if (this.dom.btnThemeToggle) {
      this.dom.btnThemeToggle.addEventListener('click', () => this.toggleTheme());
    }

    // 13. Chandrayaan-4 Lunar Mission Buttons
    if (this.dom.btnMissionChandrayaan) {
      this.dom.btnMissionChandrayaan.addEventListener('click', () => this.launchChandrayaanMission());
    }
    if (this.dom.btnAbortChandrayaan) {
      this.dom.btnAbortChandrayaan.addEventListener('click', () => this.abortChandrayaanMission());
    }

    // 14. AI Copilot Toggle Button
    if (this.dom.btnToggleAICopilot) {
      this.dom.btnToggleAICopilot.addEventListener('click', () => {
        if (this.app.aiAssistant) this.app.aiAssistant.toggleWidget();
      });
    }

    // 15. Tactical Alert Toast Close/Dismiss/Dossier
    if (this.dom.btnCloseToast) {
      this.dom.btnCloseToast.addEventListener('click', () => {
        if (this.dom.collisionAlertToast) this.dom.collisionAlertToast.classList.add('hidden');
        audio.stopEmergencySiren();
      });
    }
    if (this.dom.btnToastDismiss) {
      this.dom.btnToastDismiss.addEventListener('click', () => {
        if (this.dom.collisionAlertToast) this.dom.collisionAlertToast.classList.add('hidden');
        audio.stopEmergencySiren();
      });
    }
    if (this.dom.btnToastViewDossier) {
      this.dom.btnToastViewDossier.addEventListener('click', () => {
        if (this.dom.explosionModal) this.dom.explosionModal.classList.remove('hidden');
      });
    }
  }

  toggleLeftPanel(forceCollapsed = null) {
    if (!this.dom.leftPanel) return;
    const isCollapsed = forceCollapsed !== null ? forceCollapsed : !this.dom.leftPanel.classList.contains('collapsed');
    this.dom.leftPanel.classList.toggle('collapsed', isCollapsed);
    if (this.dom.handleLeftPane) {
      this.dom.handleLeftPane.textContent = isCollapsed ? '▶' : '◀';
      this.dom.handleLeftPane.title = isCollapsed ? 'Expand Catalog (Key: [)' : 'Collapse Catalog (Key: [)';
    }
    if (this.dom.btnToggleLeftPane) {
      this.dom.btnToggleLeftPane.classList.toggle('active', !isCollapsed);
    }
    audio.playTargetLock();
  }

  toggleRightPanel(forceCollapsed = null) {
    if (!this.dom.rightPanel) return;
    const isCollapsed = forceCollapsed !== null ? forceCollapsed : !this.dom.rightPanel.classList.contains('collapsed');
    this.dom.rightPanel.classList.toggle('collapsed', isCollapsed);
    if (this.dom.handleRightPane) {
      this.dom.handleRightPane.textContent = isCollapsed ? '◀' : '▶';
      this.dom.handleRightPane.title = isCollapsed ? 'Expand Telemetry (Key: ])' : 'Collapse Telemetry (Key: ])';
    }
    if (this.dom.btnToggleRightPane) {
      this.dom.btnToggleRightPane.classList.toggle('active', !isCollapsed);
    }
    audio.playTargetLock();
  }

  toggleTheme() {
    const isLight = document.body.classList.toggle('theme-light');
    if (this.dom.btnThemeToggle) {
      this.dom.btnThemeToggle.textContent = isLight ? '🌙 DARK MODE' : '☀️ LIGHT MODE';
    }
    if (this.app.earth3d && this.app.earth3d.scene) {
      this.app.earth3d.scene.background = isLight ? new THREE.Color(0x0c1427) : new THREE.Color(0x010206);
    }
    try {
      localStorage.setItem('astro_theme', isLight ? 'light' : 'dark');
    } catch (e) {}
    audio.playTargetLock();
  }

  launchChandrayaanMission() {
    if (!this.app.earth3d) return;
    if (this.dom.chandrayaanHud) {
      this.dom.chandrayaanHud.classList.remove('hidden');
    }
    this.app.earth3d.startChandrayaanMission(telemetry => {
      this.updateChandrayaanTelemetry(telemetry);
    });
    audio.playThrusterBurn();
  }

  abortChandrayaanMission() {
    if (this.dom.chandrayaanHud) {
      this.dom.chandrayaanHud.classList.add('hidden');
    }
    if (this.app.earth3d) {
      this.app.earth3d.stopChandrayaanMission();
    }
    audio.playTargetLock();
  }

  updateChandrayaanTelemetry(t) {
    if (this.dom.missionHudStatus) {
      this.dom.missionHudStatus.textContent = t.status;
    }
    if (this.dom.missionTeleAlt) {
      this.dom.missionTeleAlt.textContent = `${t.altitudeKm.toLocaleString()} km`;
    }
    if (this.dom.missionTeleVel) {
      this.dom.missionTeleVel.textContent = `${t.velocityKmS.toFixed(2)} km/s`;
    }
    if (this.dom.missionTeleDist) {
      this.dom.missionTeleDist.textContent = `${t.distanceToMoonKm.toLocaleString()} km`;
    }
    if (this.dom.missionTeleFuel) {
      this.dom.missionTeleFuel.textContent = `${t.fuelPercent}%`;
    }

    const badges = document.querySelectorAll('.mission-step-badge');
    badges.forEach((b, idx) => {
      b.classList.remove('active', 'completed');
      if (idx === t.stageIndex) {
        b.classList.add('active');
      } else if (idx < t.stageIndex) {
        b.classList.add('completed');
      }
    });
  }

  showCollisionToast(target, threat, relVelocityKmS, impactEnergyMJ, tntEquivalentKg, fragmentCount, horizonLabel = null) {
    if (!this.dom.collisionAlertToast || !this.dom.toastBody) return;

    audio.playEmergencySiren();
    setTimeout(() => {
      audio.stopEmergencySiren();
    }, 6000);

    const horizonTag = horizonLabel ? `<span class="event-horizon-tag" style="margin-left: 6px;">${horizonLabel.toUpperCase()}</span>` : '';

    this.dom.toastBody.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center;">
        <span style="font-weight: 700; color: #fff;">${target.name} <span class="text-red">💥</span> ${threat.name}</span>
        ${horizonTag}
      </div>
      <div style="display: flex; gap: 8px; margin-top: 4px;">
        <div class="metric-pill" style="flex: 1;">
          <span class="lbl">Rel Speed:</span>
          <span class="val text-red font-bold">${relVelocityKmS.toFixed(2)} km/s</span>
        </div>
        <div class="metric-pill" style="flex: 1;">
          <span class="lbl">Impact Energy:</span>
          <span class="val text-amber font-bold">${impactEnergyMJ.toFixed(1)} MJ</span>
        </div>
      </div>
      <div style="font-size: 10px; color: #ef4444; font-weight: 700; margin-top: 2px;">
        ⚠️ +${fragmentCount} Lethal Fragments Injected | Kessler Index: 99.4%
      </div>
    `;

    this.dom.collisionAlertToast.classList.remove('hidden');
  }

  updateClocks() {
    const now = new Date();
    if (this.dom.utcClock) {
      this.dom.utcClock.textContent = now.toISOString().replace('T', ' ').substring(0, 19) + ' UTC';
    }
    if (this.dom.istClock) {
      const istTime = new Date(now.getTime() + (5.5 * 60 * 60 * 1000));
      this.dom.istClock.textContent = istTime.toISOString().replace('T', ' ').substring(0, 19) + ' IST';
    }
    if (this.dom.jdClock) {
      const jd = (now.getTime() / 86400000) + 2440587.5;
      this.dom.jdClock.textContent = `JD ${jd.toFixed(5)}`;
    }
  }

  updateOverviewStats(objects) {
    const total = objects.length;
    const payloads = objects.filter(o => o.type === CONFIG.OBJECT_TYPES.PAYLOAD.id || o.type === CONFIG.OBJECT_TYPES.STATION.id).length;
    const rockets = objects.filter(o => o.type === CONFIG.OBJECT_TYPES.ROCKET_BODY.id).length;
    const debris = objects.filter(o => o.type === CONFIG.OBJECT_TYPES.DEBRIS.id).length;

    if (this.dom.statTotal) this.dom.statTotal.textContent = total.toLocaleString();
    if (this.dom.statPayloads) this.dom.statPayloads.textContent = payloads.toLocaleString();
    if (this.dom.statRockets) this.dom.statRockets.textContent = rockets.toLocaleString();
    if (this.dom.statDebris) this.dom.statDebris.textContent = debris.toLocaleString();

    const kessler = AIPredictor.calculateKesslerIndex(total, debris, Math.round(total * 0.7));
    if (this.dom.kesslerIndexVal) this.dom.kesslerIndexVal.textContent = `${kessler.index}%`;
    if (this.dom.kesslerBar) {
      this.dom.kesslerBar.style.width = `${kessler.index}%`;
      this.dom.kesslerBar.style.backgroundColor = kessler.statusColor;
    }
    if (this.dom.kesslerStatus) {
      this.dom.kesslerStatus.textContent = kessler.status;
      this.dom.kesslerStatus.style.color = kessler.statusColor;
    }
  }

  renderObjectsList() {
    if (!this.dom.objectsListContainer) return;
    const objects = this.app.orbitalCatalog;
    this.dom.objectsListContainer.innerHTML = '';

    const filtered = objects.filter(obj => {
      if (this.activeFilterType === "PAYLOAD" && (obj.type !== CONFIG.OBJECT_TYPES.PAYLOAD.id && obj.type !== CONFIG.OBJECT_TYPES.STATION.id)) return false;
      if (this.activeFilterType === "ROCKET_BODY" && obj.type !== CONFIG.OBJECT_TYPES.ROCKET_BODY.id) return false;
      if (this.activeFilterType === "DEBRIS" && obj.type !== CONFIG.OBJECT_TYPES.DEBRIS.id) return false;

      if (this.searchQuery) {
        const matchesName = obj.name.toLowerCase().includes(this.searchQuery);
        const matchesNorad = obj.noradId.toString().includes(this.searchQuery);
        if (!matchesName && !matchesNorad) return false;
      }
      return true;
    });

    const renderSlice = filtered.slice(0, 80);

    renderSlice.forEach(obj => {
      const item = document.createElement('div');
      item.className = `object-item ${this.app.selectedObject && this.app.selectedObject.id === obj.id ? 'selected' : ''}`;
      
      const typeInfo = CONFIG.OBJECT_TYPES[obj.type.toUpperCase()] || CONFIG.OBJECT_TYPES.DEBRIS;
      const altApprox = Math.round(obj.orbit.semiMajorAxisKm - CONFIG.EARTH_RADIUS_KM);

      item.innerHTML = `
        <div class="obj-dot" style="background-color: ${typeInfo.cssColor}"></div>
        <div class="obj-info">
          <div class="obj-title">${obj.name}</div>
          <div class="obj-meta">
            <span class="obj-norad">NORAD #${obj.noradId}</span>
            <span class="obj-alt">${altApprox} km</span>
          </div>
        </div>
      `;

      item.addEventListener('click', () => {
        this.app.earth3d.selectObject(obj);
        audio.playObjectSound(obj);
        this.renderObjectsList();
      });

      this.dom.objectsListContainer.appendChild(item);
    });
  }

  updateTelemetryHUD(obj, prop) {
    if (!obj || !prop) return;

    if (this.dom.targetName) this.dom.targetName.textContent = obj.name;
    if (this.dom.targetNorad) this.dom.targetNorad.textContent = `NORAD ID: ${obj.noradId} | ${obj.country || 'Global Space'}`;
    if (this.dom.targetAgency) this.dom.targetAgency.textContent = obj.agency || "Aerospace Organization";
    if (this.dom.targetDescription) this.dom.targetDescription.textContent = obj.description || "";

    const typeConfig = CONFIG.OBJECT_TYPES[obj.type.toUpperCase()] || CONFIG.OBJECT_TYPES.DEBRIS;
    if (this.dom.targetTypeBadge) {
      this.dom.targetTypeBadge.textContent = typeConfig.label.toUpperCase();
      this.dom.targetTypeBadge.style.borderColor = typeConfig.cssColor;
      this.dom.targetTypeBadge.style.color = typeConfig.cssColor;
    }

    // Geodetic Coordinates
    const latDir = prop.latitudeDeg >= 0 ? "N" : "S";
    const lonDir = prop.longitudeDeg >= 0 ? "E" : "W";
    if (this.dom.valLat) this.dom.valLat.textContent = `${Math.abs(prop.latitudeDeg).toFixed(2)}° ${latDir}`;
    if (this.dom.valLon) this.dom.valLon.textContent = `${Math.abs(prop.longitudeDeg).toFixed(2)}° ${lonDir}`;
    if (this.dom.valAlt) this.dom.valAlt.textContent = `${prop.altitudeKm.toFixed(1)} km`;

    // Speed & Velocity Metrics
    if (this.dom.valSpeedKmS) this.dom.valSpeedKmS.textContent = `${prop.velocityKmS.toFixed(3)} km/s`;
    if (this.dom.valSpeedKmH) this.dom.valSpeedKmH.textContent = `${Math.round(prop.velocityKmH).toLocaleString()} km/h`;
    if (this.dom.valSpeedMach) this.dom.valSpeedMach.textContent = `Mach ${prop.machNumber.toFixed(1)}`;
    if (this.dom.valSpeedLight) this.dom.valSpeedLight.textContent = OrbitalMath.formatSpeedOfLight(prop.speedOfLightRatio);

    // Direction & Flight Path Angle
    if (this.dom.valFlightPath) this.dom.valFlightPath.textContent = `${prop.flightPathAngleDeg >= 0 ? '+' : ''}${prop.flightPathAngleDeg.toFixed(2)}°`;
    if (this.dom.valDirection && prop.dirScene) {
      this.dom.valDirection.textContent = `[${prop.dirScene.x.toFixed(2)}, ${prop.dirScene.y.toFixed(2)}, ${prop.dirScene.z.toFixed(2)}]`;
    }

    // Orbital Parameters
    if (this.dom.valInc) this.dom.valInc.textContent = `${obj.orbit.inclinationDeg.toFixed(2)}°`;
    if (this.dom.valEcc) this.dom.valEcc.textContent = obj.orbit.eccentricity.toFixed(5);
    if (this.dom.valPeriod) this.dom.valPeriod.textContent = `${prop.periodMinutes.toFixed(1)} min`;
    if (this.dom.valApogee) this.dom.valApogee.textContent = `${prop.apogeeKm.toFixed(1)} km`;
    if (this.dom.valPerigee) this.dom.valPerigee.textContent = `${prop.perigeeKm.toFixed(1)} km`;

    // Check for Atmospheric Re-entry Imminent Hazard!
    if (prop.isReentryImminent) {
      if (this.dom.reentryBanner) {
        this.dom.reentryBanner.classList.remove('hidden');
        if (this.dom.reentryBannerText) {
          this.dom.reentryBannerText.innerHTML = `🔥 <strong>ATMOSPHERIC RE-ENTRY DETECTED:</strong> ${obj.name} at Alt: ${prop.altitudeKm.toFixed(1)} km | Aerothermal Heat: ${prop.atmosphericHeatIndex.toFixed(0)} W/cm² | Splashdown Target: South Pacific Ocean (Point Nemo)`;
        }
      }
      if (Math.random() < 0.15) {
        audio.playReentryAlarm();
      }
    } else {
      if (this.dom.reentryBanner) this.dom.reentryBanner.classList.add('hidden');
    }
  }

  updateConjunctionWarning(conjunctions) {
    if (!conjunctions || conjunctions.length === 0) {
      if (this.dom.conjunctionSection) this.dom.conjunctionSection.classList.add('hidden');
      if (this.dom.alertBanner) this.dom.alertBanner.classList.add('hidden');
      this.currentConjunction = null;
      return;
    }

    const topRisk = conjunctions[0];
    this.currentConjunction = topRisk;

    if (this.dom.conjunctionSection) this.dom.conjunctionSection.classList.remove('hidden');

    if (this.dom.threatObjName) this.dom.threatObjName.textContent = topRisk.threatObject.name;
    if (this.dom.threatMissDistance) {
      const distStr = topRisk.missDistanceKm < 1.0 
        ? `${Math.round(topRisk.missDistanceMeters)} meters`
        : `${topRisk.missDistanceKm.toFixed(2)} km`;
      this.dom.threatMissDistance.textContent = distStr;
    }
    if (this.dom.threatRelVelocity) this.dom.threatRelVelocity.textContent = `${topRisk.relVelocityKmS.toFixed(2)} km/s`;
    if (this.dom.threatProbability) this.dom.threatProbability.textContent = `${topRisk.probabilityPercent}%`;
    if (this.dom.threatTca) this.dom.threatTca.textContent = `T-${topRisk.tcaSeconds}s`;
    if (this.dom.threatImpactEnergy) this.dom.threatImpactEnergy.textContent = `${topRisk.impactEnergyMJ.toFixed(1)} MJ (~${topRisk.tntEquivalentKg.toFixed(1)} kg TNT)`;

    if (this.dom.threatRiskBadge) {
      this.dom.threatRiskBadge.textContent = topRisk.risk.name;
      this.dom.threatRiskBadge.style.backgroundColor = topRisk.risk.color;
      this.dom.threatRiskBadge.style.color = "#000";
    }

    if (topRisk.risk === CONFIG.RISK_LEVELS.CRITICAL) {
      if (this.dom.alertBanner) {
        this.dom.alertBanner.classList.remove('hidden');
        if (this.dom.alertBannerText) {
          this.dom.alertBannerText.innerHTML = `⚠️ <strong>CRITICAL CONJUNCTION DETECTED:</strong> ${topRisk.targetObject.name} vs ${topRisk.threatObject.name} | Miss: ${Math.round(topRisk.missDistanceMeters)}m | Risk: ${topRisk.probabilityPercent}%`;
        }
      }
      if (Math.random() < 0.12) {
        audio.playCollisionAlarm();
      }
    } else {
      if (this.dom.alertBanner) this.dom.alertBanner.classList.add('hidden');
    }
  }

  /**
   * Simulates a Hypervelocity Impact Event with 3D Explosion, Shockwave, Camera Shake & Fragmentation!
   */
  simulateCollisionEvent() {
    // 1. Identify Target Spacecraft (Selected object or top active spacecraft)
    let target = this.app.selectedObject;
    if (!target && this.currentConjunction) {
      target = this.currentConjunction.targetObject;
    }
    if (!target) {
      target = this.app.orbitalCatalog.find(o => o.type === CONFIG.OBJECT_TYPES.PAYLOAD.id || o.type === CONFIG.OBJECT_TYPES.STATION.id) || this.app.orbitalCatalog[0];
      if (target) {
        this.selectObject(target);
      }
    }

    if (!target) return;

    // 2. Identify Intercepting Lethal Threat / Debris
    let threat = this.currentConjunction ? this.currentConjunction.threatObject : null;
    if (!threat) {
      threat = this.app.orbitalCatalog.find(o => o.type === CONFIG.OBJECT_TYPES.DEBRIS.id && o.id !== target.id) || {
        id: "DEB-COSMOS-2251",
        name: "COSMOS 2251 DEB [KINETIC INTERCEPTOR]",
        type: CONFIG.OBJECT_TYPES.DEBRIS.id,
        massKg: 85.0,
        orbit: {
          semiMajorAxisKm: target.orbit.semiMajorAxisKm + 1.8,
          eccentricity: 0.015,
          inclinationDeg: (target.orbit.inclinationDeg + 28.0) % 180,
          raanDeg: target.orbit.raanDeg + 40.0,
          argPerigeeDeg: 0,
          meanAnomalyDeg: 0
        }
      };
    }

    // 3. Determine Exact 3D Collision Coordinates
    let pos = null;
    if (this.app.selectedObjectProp && this.app.selectedObjectProp.scenePos) {
      pos = { ...this.app.selectedObjectProp.scenePos };
    } else {
      const targetIdx = this.app.orbitalCatalog.findIndex(o => o.id === target.id);
      if (targetIdx !== -1 && this.app.earth3d.objectMeshes[targetIdx]) {
        pos = {
          x: this.app.earth3d.objectMeshes[targetIdx].position.x,
          y: this.app.earth3d.objectMeshes[targetIdx].position.y,
          z: this.app.earth3d.objectMeshes[targetIdx].position.z
        };
      } else {
        const prop = OrbitalMath.propagateKepler(target.orbit, Date.now());
        pos = { ...prop.scenePos };
      }
    }

    if (!pos || isNaN(pos.x)) {
      pos = { x: 0, y: 5.65, z: 0 };
    }

    // 4. Collision Impact Dynamics & Physics
    const relVelocityKmS = this.currentConjunction ? this.currentConjunction.relVelocityKmS : +(11.2 + Math.random() * 3.8).toFixed(2);
    const impactEnergyMJ = this.currentConjunction ? this.currentConjunction.impactEnergyMJ : +(740 + Math.random() * 450).toFixed(1);
    const tntEquivalentKg = +(impactEnergyMJ / 4.184).toFixed(1);

    // 5. Trigger 3D Explosion, Shockwaves & Tactical Camera Shake
    this.app.earth3d.triggerCollisionExplosion(pos);
    this.app.earth3d.shakeCamera(0.35, 750);
    audio.playExplosion();

    // Smooth-center the camera onto the explosion site
    if (this.app.earth3d.controls) {
      this.app.earth3d.controls.target.set(pos.x * 0.4, pos.y * 0.4, pos.z * 0.4);
    }

    // 6. Spawn 35 Hypervelocity Kessler Fragmentation Debris
    const fragmentCount = 35;
    const newFrags = spawnBreakupDebris(target, threat, fragmentCount);
    newFrags.forEach(frag => {
      this.app.orbitalCatalog.push(frag);
      const mesh = this.app.earth3d.createDetailedSatelliteMesh(frag);
      this.app.earth3d.scene.add(mesh);
      this.app.earth3d.objectMeshes.push(mesh);
      this.app.earth3d.debrisRotations.push({
        rx: (Math.random() - 0.5) * 0.12,
        ry: (Math.random() - 0.5) * 0.12,
        rz: (Math.random() - 0.5) * 0.12
      });
    });

    // 7. Update Overview Statistics & Objects List
    this.updateOverviewStats(this.app.orbitalCatalog);
    this.renderObjectsList();

    // 8. Elevate Kessler Syndrome Cascade Index to Critical Runaway Level
    if (this.dom.kesslerIndexVal) this.dom.kesslerIndexVal.textContent = "98.4%";
    if (this.dom.kesslerBar) {
      this.dom.kesslerBar.style.width = "98.4%";
      this.dom.kesslerBar.style.background = "var(--color-red)";
    }
    if (this.dom.kesslerStatus) {
      this.dom.kesslerStatus.textContent = "RUNAWAY KESSLER CASCADE THREAT (CRITICAL)";
      this.dom.kesslerStatus.className = "kessler-status status-critical";
    }

    // 9. Render Comprehensive Collision Report Dossier
    if (this.dom.explosionDetails) {
      this.dom.explosionDetails.innerHTML = `
        <div class="plan-metric">
          <span class="label">Event Classification:</span>
          <span class="value text-red font-bold">HYPERVELOCITY CATASTROPHIC BREAKUP</span>
        </div>
        <div class="plan-metric">
          <span class="label">Collided Objects:</span>
          <span class="value text-cyan">${target.name} <span class="text-red">💥</span> ${threat.name}</span>
        </div>
        <div class="plan-metric">
          <span class="label">Impact Relative Velocity:</span>
          <span class="value text-red font-bold">${relVelocityKmS} km/s (~${Math.round(relVelocityKmS * 3600).toLocaleString()} km/h)</span>
        </div>
        <div class="plan-metric">
          <span class="label">Kinetic Energy Released:</span>
          <span class="value text-amber font-bold">${impactEnergyMJ} Megajoules (~${tntEquivalentKg} kg TNT equivalent)</span>
        </div>
        <hr class="divider" />
        <div class="plan-metric highlight">
          <span class="label">New Lethal Fragments Spawned:</span>
          <span class="value text-red font-bold">+${fragmentCount} Tracked Hypervelocity Fragments Injected</span>
        </div>
        <div class="plan-metric">
          <span class="label">Orbital Altitude / Regime:</span>
          <span class="value text-cyan">Low Earth Orbit (~${Math.round(target.orbit.semiMajorAxisKm - CONFIG.EARTH_RADIUS_KM)} km Altitude)</span>
        </div>
        <div class="plan-metric">
          <span class="label">Kessler Syndrome Status:</span>
          <span class="value text-red font-bold">RUNAWAY CASCADE THREAT ELEVATED</span>
        </div>
      `;
    }

    // Trigger sudden non-blocking tactical alert toast (lets 3D Earth explosion remain 100% visible!)
    this.showCollisionToast(target, threat, relVelocityKmS, impactEnergyMJ, tntEquivalentKg, fragmentCount);
  }

  openAvoidanceModal() {
    if (!this.currentConjunction) {
      let target = this.app.selectedObject || this.app.orbitalCatalog[0];
      let threat = this.app.orbitalCatalog.find(o => o.type === CONFIG.OBJECT_TYPES.DEBRIS.id && o.id !== target.id) || {
        id: "DEB-COSMOS-2251",
        name: "COSMOS 2251 DEB [KINETIC INTERCEPTOR]",
        type: CONFIG.OBJECT_TYPES.DEBRIS.id,
        orbit: { ...target.orbit, semiMajorAxisKm: target.orbit.semiMajorAxisKm + 0.4 }
      };
      this.currentConjunction = {
        targetObject: target,
        threatObject: threat,
        missDistanceKm: 0.38,
        missDistanceMeters: 380,
        relVelocityKmS: 11.4,
        probabilityPercent: 94.2,
        tcaSeconds: 18,
        impactEnergyMJ: 786.5,
        tntEquivalentKg: 188.0,
        risk: CONFIG.RISK_LEVELS.CRITICAL
      };
    }

    const plan = AIPredictor.planAvoidanceManeuver(this.currentConjunction);

    if (this.dom.maneuverDetails) {
      this.dom.maneuverDetails.innerHTML = `
        <div class="plan-metric">
          <span class="label">Target Spacecraft:</span>
          <span class="value text-cyan">${this.currentConjunction.targetObject.name}</span>
        </div>
        <div class="plan-metric">
          <span class="label">Incoming Interceptor:</span>
          <span class="value text-red">${this.currentConjunction.threatObject.name}</span>
        </div>
        <div class="plan-metric">
          <span class="label">Current Miss Distance:</span>
          <span class="value text-red">${plan.originalMissMeters} meters</span>
        </div>
        <div class="plan-metric">
          <span class="label">Projected Collision Risk:</span>
          <span class="value text-red">${plan.originalProbability}</span>
        </div>
        <hr class="divider" />
        <div class="plan-metric highlight">
          <span class="label">AI Recommended Thrust Vector:</span>
          <span class="value text-emerald font-bold">${plan.maneuverType} (+${plan.deltaVMPerSec} m/s)</span>
        </div>
        <div class="plan-metric">
          <span class="label">Thruster Burn Duration:</span>
          <span class="value">${plan.burnDurationSeconds} seconds</span>
        </div>
        <div class="plan-metric">
          <span class="label">Fuel Propellant Penalty:</span>
          <span class="value">${plan.fuelPenaltyKg} kg (Hydrazine)</span>
        </div>
        <div class="plan-metric">
          <span class="label">Post-Burn New Miss Distance:</span>
          <span class="value text-emerald font-bold">${plan.projectedMissKm} km</span>
        </div>
        <div class="plan-metric">
          <span class="label">Post-Burn Residual Risk:</span>
          <span class="value text-emerald">${plan.projectedProbability} (NOMINAL)</span>
        </div>
      `;
    }

    if (this.dom.maneuverModal) {
      this.dom.maneuverModal.classList.remove('hidden');
    }
    audio.playRadarPing();
  }

  executeAvoidanceBurn() {
    if (!this.currentConjunction) return;
    audio.playThrusterBurn();

    if (this.dom.btnConfirmBurn) {
      this.dom.btnConfirmBurn.disabled = true;
      this.dom.btnConfirmBurn.textContent = "FIRING PROPULSION THRUSTERS...";
    }

    setTimeout(() => {
      if (this.currentConjunction.targetObject && this.currentConjunction.targetObject.orbit) {
        this.currentConjunction.targetObject.orbit.semiMajorAxisKm += 3.5;
      }

      if (this.dom.btnConfirmBurn) {
        this.dom.btnConfirmBurn.disabled = false;
        this.dom.btnConfirmBurn.textContent = "MANEUVER COMPLETE - CONJUNCTION RESOLVED!";
        this.dom.btnConfirmBurn.classList.add('btn-success');
      }

      setTimeout(() => {
        if (this.dom.maneuverModal) this.dom.maneuverModal.classList.add('hidden');
        if (this.dom.alertBanner) this.dom.alertBanner.classList.add('hidden');
        if (this.dom.conjunctionSection) this.dom.conjunctionSection.classList.add('hidden');
        this.app.earth3d.hideConjunctionLaser();
        audio.playRadarPing();
      }, 1200);
    }, 1500);
  }

  /**
   * Switch Left Panel View between SSN Catalog and Collision Timetable
   */
  switchLeftTab(tabName) {
    if (tabName === 'timetable') {
      if (this.dom.tabTimetable) this.dom.tabTimetable.classList.add('active');
      if (this.dom.tabCatalog) this.dom.tabCatalog.classList.remove('active');
      if (this.dom.viewTimetable) {
        this.dom.viewTimetable.classList.remove('hidden');
        this.dom.viewTimetable.style.display = 'flex';
      }
      if (this.dom.viewCatalog) {
        this.dom.viewCatalog.classList.add('hidden');
        this.dom.viewCatalog.style.display = 'none';
      }
      this.renderTimetable();
      audio.playRadarPing();
    } else {
      if (this.dom.tabCatalog) this.dom.tabCatalog.classList.add('active');
      if (this.dom.tabTimetable) this.dom.tabTimetable.classList.remove('active');
      if (this.dom.viewCatalog) {
        this.dom.viewCatalog.classList.remove('hidden');
        this.dom.viewCatalog.style.display = 'flex';
      }
      if (this.dom.viewTimetable) {
        this.dom.viewTimetable.classList.add('hidden');
        this.dom.viewTimetable.style.display = 'none';
      }
      audio.playTargetLock();
    }
  }

  /**
   * Initialize multi-horizon forecast events
   */
  initForecast(events) {
    this.forecastEvents = events;
    if (this.dom.timetableBadgeCount) {
      this.dom.timetableBadgeCount.textContent = events.length;
    }
    this.renderTimetable();
  }

  /**
   * Render Multi-Horizon Collision Timetable Cards with Action Triggers
   */
  renderTimetable() {
    if (!this.dom.timetableList) return;
    this.dom.timetableList.innerHTML = '';

    let filtered = this.forecastEvents;
    if (this.activeHorizonFilter && this.activeHorizonFilter !== 'ALL') {
      filtered = this.forecastEvents.filter(e => {
        const key = (typeof e.timeHorizon === 'object' && e.timeHorizon !== null)
          ? (e.timeHorizon.key || '')
          : String(e.timeHorizon || '');
        return key.toLowerCase() === this.activeHorizonFilter.toLowerCase() ||
               (e.horizonKey && e.horizonKey.toLowerCase() === this.activeHorizonFilter.toLowerCase());
      });
    }

    if (filtered.length === 0) {
      this.dom.timetableList.innerHTML = `
        <div style="padding: 24px 12px; text-align: center; color: #94a3b8; font-size: 11px;">
          No projected collisions found in the "${this.activeHorizonFilter.toUpperCase()}" horizon filter.
        </div>
      `;
      return;
    }

    filtered.forEach(ev => {
      const card = document.createElement('div');
      const remainingSec = ev.remainingSeconds !== undefined ? ev.remainingSeconds : (ev.tcaSecondsOffset || 0);
      const isCritical = remainingSec <= 3600 || ev.risk === CONFIG.RISK_LEVELS.CRITICAL;
      card.className = `timetable-card ${isCritical ? 'critical' : ''}`;

      const target = ev.target || ev.targetObject || { name: 'Target Spacecraft', type: 'PAYLOAD', orbit: { semiMajorAxisKm: 6871 } };
      const threat = ev.threat || ev.threatObject || { name: 'Debris Interceptor', type: 'DEBRIS', orbit: { semiMajorAxisKm: 6873 } };
      const horizonLabel = typeof ev.timeHorizon === 'object' && ev.timeHorizon !== null
        ? (ev.timeHorizon.label || ev.timeHorizon.key || 'TIMELINE')
        : (String(ev.timeHorizon || 'TIMELINE'));

      const missStr = (ev.missDistanceKm || 0) < 1.0 
        ? `${Math.round(ev.missDistanceMeters || (ev.missDistanceKm * 1000))} meters`
        : `${(ev.missDistanceKm || 1).toFixed(2)} km`;

      card.innerHTML = `
        <div class="timetable-card-header">
          <span class="event-horizon-tag">${horizonLabel.toUpperCase()}</span>
          <span class="tca-countdown-badge ${isCritical ? 'critical' : ''}" data-event-id="${ev.id}">
            ⏱️ ${AIPredictor.formatCountdownClock(remainingSec)}
          </span>
        </div>

        <div class="event-pair-title">
          <span class="target-name" title="${target.name}">${target.name}</span>
          <span style="color: #64748b; font-size: 10px;">⚡ vs ⚡</span>
          <span class="threat-name" title="${threat.name}">${threat.name}</span>
        </div>

        <div class="timetable-metrics-grid">
          <div class="metric-pill">
            <span class="lbl">Miss Dist:</span>
            <span class="val ${(ev.missDistanceKm || 1) < 1 ? 'text-red font-bold' : 'text-amber'}">${missStr}</span>
          </div>
          <div class="metric-pill">
            <span class="lbl">Rel Speed:</span>
            <span class="val text-amber font-bold">${(ev.relVelocityKmS || 11.2).toFixed(2)} km/s</span>
          </div>
          <div class="metric-pill">
            <span class="lbl">Prob (Pc):</span>
            <span class="val text-red font-bold">${ev.probabilityPercent || 90}%</span>
          </div>
          <div class="metric-pill">
            <span class="lbl">Altitude:</span>
            <span class="val text-cyan">${Math.round(ev.targetAltitudeKm || 500)} km</span>
          </div>
          <div class="metric-pill" style="grid-column: span 2;">
            <span class="lbl">Projected TCA:</span>
            <span class="val text-cyan font-bold" data-human-id="${ev.id}">${AIPredictor.formatHumanDuration(remainingSec)}</span>
          </div>
        </div>

        <div class="timetable-actions-row">
          <button class="btn-event-action btn-event-focus" data-ev-id="${ev.id}">
            🎯 FOCUS PAIR
          </button>
          <button class="btn-event-action btn-event-maneuver" data-ev-id="${ev.id}">
            ⚡ AI BURN
          </button>
          <button class="btn-event-action btn-event-simulate" data-ev-id="${ev.id}">
            💥 IMPACT NOW
          </button>
        </div>
      `;

      // Button Listeners
      const btnFocus = card.querySelector('.btn-event-focus');
      if (btnFocus) {
        btnFocus.addEventListener('click', (e) => {
          e.stopPropagation();
          this.app.earth3d.focusConjunctionPair(target, threat, ev.projectedIntersectionPos);
          if (target && target.orbit) {
            const prop = OrbitalMath.propagateKepler(target.orbit, Date.now());
            this.app.onObjectSelected(target, prop);
          }
          audio.playRadarPing();
        });
      }

      const btnManeuver = card.querySelector('.btn-event-maneuver');
      if (btnManeuver) {
        btnManeuver.addEventListener('click', (e) => {
          e.stopPropagation();
          this.currentConjunction = {
            targetObject: target,
            threatObject: threat,
            missDistanceKm: ev.missDistanceKm || 0.35,
            missDistanceMeters: ev.missDistanceMeters || 350,
            relVelocityKmS: ev.relVelocityKmS || 11.2,
            probabilityPercent: ev.probabilityPercent || 92.5,
            tcaSeconds: Math.min(remainingSec || 9999, 9999),
            impactEnergyMJ: ev.impactEnergyMJ || 750,
            tntEquivalentKg: ev.tntEquivalentKg || 180,
            risk: ev.risk || CONFIG.RISK_LEVELS.CRITICAL
          };
          this.openAvoidanceModal();
        });
      }

      const btnSimulate = card.querySelector('.btn-event-simulate');
      if (btnSimulate) {
        btnSimulate.addEventListener('click', (e) => {
          e.stopPropagation();
          this.simulateForecastImpact(ev);
        });
      }

      this.dom.timetableList.appendChild(card);
    });
  }

  /**
   * Update real-time ticking countdowns on all active timetable cards
   */
  updateTimetableCountdowns(stepSeconds) {
    if (!this.forecastEvents || this.forecastEvents.length === 0) return;

    for (let i = 0; i < this.forecastEvents.length; i++) {
      const ev = this.forecastEvents[i];
      let rem = (ev.remainingSeconds !== undefined ? ev.remainingSeconds : ev.tcaSecondsOffset) - stepSeconds;
      if (rem <= 0) {
        rem = ev.tcaSecondsOffset || 3600; // Continuous orbital cycle reset
      }
      ev.remainingSeconds = rem;

      const badge = this.dom.timetableList?.querySelector(`.tca-countdown-badge[data-event-id="${ev.id}"]`);
      if (badge) {
        badge.innerHTML = `⏱️ ${AIPredictor.formatCountdownClock(ev.remainingSeconds)}`;
        if (ev.remainingSeconds <= 3600) {
          badge.classList.add('critical');
        } else {
          badge.classList.remove('critical');
        }
      }

      const humanEl = this.dom.timetableList?.querySelector(`[data-human-id="${ev.id}"]`);
      if (humanEl) {
        humanEl.textContent = AIPredictor.formatHumanDuration(ev.remainingSeconds);
      }
    }
  }

  /**
   * Simulates a Direct Hypervelocity Collision for a specific forecast conjunction pair
   */
  simulateForecastImpact(forecastEvent) {
    if (!forecastEvent) return;
    const target = forecastEvent.target || forecastEvent.targetObject || this.app.selectedObject;
    const threat = forecastEvent.threat || forecastEvent.threatObject;
    if (!target) return;

    const horizonLabel = typeof forecastEvent.timeHorizon === 'object' && forecastEvent.timeHorizon !== null
      ? (forecastEvent.timeHorizon.label || forecastEvent.timeHorizon.key || 'TIMELINE')
      : (String(forecastEvent.timeHorizon || 'TIMELINE'));

    // Use precomputed intersection position or object position
    let pos = forecastEvent.projectedIntersectionPos;
    if (!pos || isNaN(pos.x)) {
      if (this.app.selectedObjectProp && this.app.selectedObjectProp.scenePos) {
        pos = { ...this.app.selectedObjectProp.scenePos };
      } else {
        const prop = OrbitalMath.propagateKepler(target.orbit, Date.now());
        pos = { ...prop.scenePos };
      }
    }

    const relVelocityKmS = forecastEvent.relVelocityKmS;
    const impactEnergyMJ = forecastEvent.impactEnergyMJ;
    const tntEquivalentKg = forecastEvent.tntEquivalentKg;

    // 1. Trigger 3D Explosion, Shockwaves & Camera Shake
    this.app.earth3d.triggerCollisionExplosion(pos);
    this.app.earth3d.shakeCamera(0.4, 850);
    audio.playExplosion();

    // Smooth-center camera on the explosion site
    if (this.app.earth3d.controls) {
      this.app.earth3d.controls.target.set(pos.x * 0.4, pos.y * 0.4, pos.z * 0.4);
    }

    // 2. Spawn 35 Hypervelocity Kessler Fragmentation Debris
    const fragmentCount = 35;
    const newFrags = spawnBreakupDebris(target, threat, fragmentCount);
    newFrags.forEach(frag => {
      this.app.orbitalCatalog.push(frag);
      const mesh = this.app.earth3d.createDetailedSatelliteMesh(frag);
      this.app.earth3d.scene.add(mesh);
      this.app.earth3d.objectMeshes.push(mesh);
      this.app.earth3d.debrisRotations.push({
        rx: (Math.random() - 0.5) * 0.12,
        ry: (Math.random() - 0.5) * 0.12,
        rz: (Math.random() - 0.5) * 0.12
      });
    });

    // 3. Update Overview Statistics & Objects List
    this.updateOverviewStats(this.app.orbitalCatalog);
    this.renderObjectsList();

    // 4. Elevate Kessler Syndrome Cascade Index
    if (this.dom.kesslerIndexVal) this.dom.kesslerIndexVal.textContent = "99.4%";
    if (this.dom.kesslerBar) {
      this.dom.kesslerBar.style.width = "99.4%";
      this.dom.kesslerBar.style.background = "var(--color-red)";
    }
    if (this.dom.kesslerStatus) {
      this.dom.kesslerStatus.textContent = "RUNAWAY KESSLER CASCADE THREAT (CRITICAL)";
      this.dom.kesslerStatus.className = "kessler-status status-critical";
    }

    // 5. Render Collision Report Dossier Modal
    if (this.dom.explosionDetails) {
      this.dom.explosionDetails.innerHTML = `
        <div class="plan-metric">
          <span class="label">Event Horizon Forecast:</span>
          <span class="value text-amber font-bold">${horizonLabel.toUpperCase()} FORECAST IMPACT</span>
        </div>
        <div class="plan-metric">
          <span class="label">Collided Objects:</span>
          <span class="value text-cyan">${target.name} <span class="text-red">💥</span> ${threat.name}</span>
        </div>
        <div class="plan-metric">
          <span class="label">Impact Relative Velocity:</span>
          <span class="value text-red font-bold">${relVelocityKmS} km/s (~${Math.round(relVelocityKmS * 3600).toLocaleString()} km/h)</span>
        </div>
        <div class="plan-metric">
          <span class="label">Kinetic Energy Released:</span>
          <span class="value text-amber font-bold">${impactEnergyMJ} Megajoules (~${tntEquivalentKg} kg TNT equivalent)</span>
        </div>
        <hr class="divider" />
        <div class="plan-metric highlight">
          <span class="label">New Lethal Fragments Spawned:</span>
          <span class="value text-red font-bold">+${fragmentCount} Tracked Hypervelocity Fragments Injected</span>
        </div>
        <div class="plan-metric">
          <span class="label">Orbital Altitude / Regime:</span>
          <span class="value text-cyan">${forecastEvent.regime} (~${Math.round(forecastEvent.targetAltitudeKm)} km Altitude)</span>
        </div>
        <div class="plan-metric">
          <span class="label">Kessler Syndrome Status:</span>
          <span class="value text-red font-bold">RUNAWAY CASCADE THREAT ELEVATED</span>
        </div>
      `;
    }

    // Trigger sudden non-blocking tactical alert toast (lets 3D Earth explosion remain 100% visible!)
    this.showCollisionToast(target, threat, relVelocityKmS, impactEnergyMJ, tntEquivalentKg, fragmentCount, horizonLabel);
  }

  /**
   * Render Live Proximity Radar on Right Telemetry Panel
   */
  renderProximityRadar(nearestThreats) {
    if (!this.dom.proximityRadarList) return;
    this.dom.proximityRadarList.innerHTML = '';

    if (!nearestThreats || nearestThreats.length === 0) {
      this.dom.proximityRadarList.innerHTML = `
        <div style="color: #64748b; font-size: 10px; padding: 6px 4px; text-align: center;">
          No immediate proximity hazards within orbital screening envelope.
        </div>
      `;
      return;
    }

    nearestThreats.forEach(t => {
      const threat = t.object;
      const item = document.createElement('div');
      item.className = 'proximity-radar-item';

      item.innerHTML = `
        <div class="proximity-item-info">
          <div class="proximity-item-name" title="${threat.name}">${threat.name}</div>
          <div class="proximity-item-speed">
            Rel: <strong>${t.relSpeedKmS.toFixed(2)} km/s</strong> | Status: <strong>${t.hazardLevel}</strong>
          </div>
        </div>
        <div class="proximity-item-dist ${t.badgeClass}">
          ${t.distanceKm} km
        </div>
      `;

      item.addEventListener('click', () => {
        if (this.app.selectedObject && this.app.selectedObjectProp) {
          const threatProp = OrbitalMath.propagateKepler(threat.orbit, Date.now());
          this.app.earth3d.focusConjunctionPair(this.app.selectedObject, threat, threatProp.scenePos);
        } else {
          this.app.earth3d.selectObject(threat);
        }
        audio.playRadarPing();
      });

      this.dom.proximityRadarList.appendChild(item);
    });
  }
}

