/**
 * PROCEDURAL SPACE & TELEMETRY AUDIO SYNTHESIZER (ADVANCED)
 * Binary Hacks 4.0 - PS-07
 * Pure Web Audio API:
 * - Distinct Sound Profiles for Satellites, Space Stations, Rocket Bodies & Debris
 * - Satellite Digital Telemetry Downlink Chirps
 * - Space Station Life Support & Comm Chimes
 * - Derelict Rocket Body Metallic Resonance
 * - Tumbling Space Debris Clink & Doppler Shift
 * - Cosmic Pulsar & Solar Wind Generators
 * - Hypervelocity Collision Explosion & Re-entry Sirens
 */

export class AudioEngine {
  constructor() {
    this.ctx = null;
    this.isMuted = false;
    this.ambientOsc1 = null;
    this.ambientOsc2 = null;
    this.ambientGain = null;
    this.isAmbientPlaying = false;

    // Real User-Uploaded Audio Assets (Radar Ping, Debris Collision Break, Alert Siren)
    this.radarAudio = null;
    this.debrisAudio = null;
    this.alertSirenAudio = null;
    this.initAudioElements();
  }

  initAudioElements() {
    try {
      const radarSrc = (typeof window !== 'undefined' && window.EMBEDDED_AUDIO && window.EMBEDDED_AUDIO.radarPing) ? window.EMBEDDED_AUDIO.radarPing : 'audio/radar-ping.mp3';
      const debrisSrc = (typeof window !== 'undefined' && window.EMBEDDED_AUDIO && window.EMBEDDED_AUDIO.debrisCollision) ? window.EMBEDDED_AUDIO.debrisCollision : 'audio/debris-collision.mp3';
      const sirenSrc = (typeof window !== 'undefined' && window.EMBEDDED_AUDIO && window.EMBEDDED_AUDIO.alertSiren) ? window.EMBEDDED_AUDIO.alertSiren : 'audio/alert-siren.mp3';

      this.radarAudio = new Audio(radarSrc);
      this.radarAudio.volume = 0.85;

      this.debrisAudio = new Audio(debrisSrc);
      this.debrisAudio.volume = 0.95;

      this.alertSirenAudio = new Audio(sirenSrc);
      this.alertSirenAudio.volume = 0.85;
      this.alertSirenAudio.loop = true;
    } catch (e) {
      console.warn("Real audio init fallback to WebAudio synth:", e);
    }
  }

  init() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  toggleMute() {
    this.isMuted = !this.isMuted;
    if (this.isMuted) {
      this.stopAmbientHum();
    } else {
      this.startAmbientHum();
    }
    return this.isMuted;
  }

  /**
   * Routes the sound dynamically based on what object the user clicks!
   */
  playObjectSound(obj) {
    if (!obj || this.isMuted) return;
    this.init();

    if (obj.type === 'station') {
      this.playSpaceStationAmbience();
    } else if (obj.type === 'payload') {
      this.playSatelliteTransmission();
    } else if (obj.type === 'rocket_body') {
      this.playRocketBodyEcho();
    } else {
      this.playDebrisTumblePing();
    }
  }

  /**
   * 1. ACTIVE SATELLITE: Digital FSK Telemetry Downlink Data Chirps
   */
  playSatelliteTransmission() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      // FSK modulation tones: 1200Hz & 2200Hz Bell-202 satellite radio tones
      const freqs = [1200, 2200, 1600, 2400, 1200];
      freqs.forEach((freq, idx) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = "sine";
        osc.frequency.setValueAtTime(freq, now + idx * 0.05);

        gain.gain.setValueAtTime(0.06, now + idx * 0.05);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + (idx + 1) * 0.05);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now + idx * 0.05);
        osc.stop(now + (idx + 1) * 0.05);
      });
    } catch (e) {
      console.warn("Satellite audio error:", e);
    }
  }

  /**
   * 2. MANNED SPACE STATION: Pressurized Lab Hum & Crew Intercom Beep
   */
  playSpaceStationAmbience() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      // Two-tone NASA Quindar intercom beep (2525Hz & 2475Hz)
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(2525, now);
      osc.frequency.setValueAtTime(2475, now + 0.12);

      gain.gain.setValueAtTime(0.07, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.28);
    } catch (e) {
      console.warn("Station audio error:", e);
    }
  }

  /**
   * 3. DERELICT ROCKET BODY: Hollow Metallic Hull Resonance & Low Rumble
   */
  playRocketBodyEcho() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = "triangle";
      osc.frequency.setValueAtTime(165, now); // Low resonant hull vibration
      osc.frequency.exponentialRampToValueAtTime(82, now + 0.45);

      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.52);
    } catch (e) {
      console.warn("Rocket audio error:", e);
    }
  }

  /**
   * 4. DEBRIS FRAGMENT: Tumbling Metallic Clink & Doppler Shift Ping
   */
  playDebrisTumblePing() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = "sine";
      // High-pitched tumbling metallic scrape with Doppler drop
      const startPitch = 2800 + Math.random() * 600;
      osc.frequency.setValueAtTime(startPitch, now);
      osc.frequency.exponentialRampToValueAtTime(startPitch * 0.4, now + 0.18);

      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 0.22);
    } catch (e) {
      console.warn("Debris audio error:", e);
    }
  }

  /**
   * 5. COSMIC PULSAR: Radio Telescope Rhythmic Signal (CP-1919)
   */
  playPulsarBeep() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      for (let p = 0; p < 4; p++) {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();

        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(440, now + p * 0.12);
        osc.frequency.exponentialRampToValueAtTime(110, now + p * 0.12 + 0.06);

        gain.gain.setValueAtTime(0.06, now + p * 0.12);
        gain.gain.exponentialRampToValueAtTime(0.001, now + p * 0.12 + 0.08);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start(now + p * 0.12);
        osc.stop(now + p * 0.12 + 0.09);
      }
    } catch (e) {
      console.warn("Pulsar audio error:", e);
    }
  }

  /**
   * 6. SOLAR WIND: Ethereal Deep Space Plasma Sweep
   */
  playCosmicWind() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const bufferSize = this.ctx.sampleRate * 2.0;
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }
      const noise = this.ctx.createBufferSource();
      noise.buffer = noiseBuffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = "bandpass";
      filter.frequency.setValueAtTime(220, now);
      filter.frequency.linearRampToValueAtTime(540, now + 1.0);
      filter.frequency.linearRampToValueAtTime(180, now + 2.0);
      filter.Q.setValueAtTime(3.5, now);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.01, now);
      gain.gain.linearRampToValueAtTime(0.12, now + 0.8);
      gain.gain.linearRampToValueAtTime(0.001, now + 2.0);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      noise.start(now);
      noise.stop(now + 2.0);
    } catch (e) {
      console.warn("Cosmic wind error:", e);
    }
  }

  /**
   * Radar Sweep Ping (Real Satellite Chirp)
   */
  playRadarPing() {
    if (this.isMuted) return;
    if (this.radarAudio) {
      try {
        this.radarAudio.currentTime = 0;
        this.radarAudio.play().catch(() => {});
      } catch (e) {}
    }
    this.init();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = "sine";
      osc.frequency.setValueAtTime(1400, now);
      osc.frequency.exponentialRampToValueAtTime(700, now + 0.25);

      gain.gain.setValueAtTime(0.08, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.4);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.45);
    } catch (e) {
      console.warn("Radar ping error:", e);
    }
  }

  /**
   * Proximity Emergency Siren (Real Mayyote Siren Audio)
   */
  playCollisionAlarm() {
    if (this.isMuted) return;
    this.playEmergencySiren();
    this.init();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(880, now);
      osc.frequency.setValueAtTime(620, now + 0.15);
      osc.frequency.setValueAtTime(880, now + 0.3);
      osc.frequency.setValueAtTime(620, now + 0.45);

      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.65);
    } catch (e) {
      console.warn("Alarm error:", e);
    }
  }

  playEmergencySiren() {
    if (this.isMuted) return;
    if (this.alertSirenAudio) {
      try {
        this.alertSirenAudio.currentTime = 0;
        this.alertSirenAudio.play().catch(() => {});
      } catch (e) {}
    }
  }

  stopEmergencySiren() {
    if (this.alertSirenAudio) {
      try {
        this.alertSirenAudio.pause();
        this.alertSirenAudio.currentTime = 0;
      } catch (e) {}
    }
  }

  /**
   * Target Lock Beep
   */
  playTargetLock() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = "triangle";
      osc.frequency.setValueAtTime(1800, now);
      osc.frequency.exponentialRampToValueAtTime(2400, now + 0.08);

      gain.gain.setValueAtTime(0.07, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.12);
    } catch (e) {
      console.warn("Lock error:", e);
    }
  }

  /**
   * Thruster Burn
   */
  playThrusterBurn() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const bufferSize = this.ctx.sampleRate * 1.5;
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = Math.random() * 2 - 1;
      }
      const whiteNoise = this.ctx.createBufferSource();
      whiteNoise.buffer = noiseBuffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = "bandpass";
      filter.frequency.setValueAtTime(320, now);
      filter.Q.setValueAtTime(1.5, now);

      const gain = this.ctx.createGain();
      gain.gain.setValueAtTime(0.001, now);
      gain.gain.linearRampToValueAtTime(0.2, now + 0.3);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 1.4);

      whiteNoise.connect(filter);
      filter.connect(gain);
      gain.connect(this.ctx.destination);

      whiteNoise.start(now);
      whiteNoise.stop(now + 1.5);
    } catch (e) {
      console.warn("Thruster error:", e);
    }
  }

  /**
   * Hypervelocity Collision Explosion & Breakup FX (Real Lordsonny Two Debris Collision)
   */
  playExplosion() {
    if (this.isMuted) return;
    if (this.debrisAudio) {
      try {
        this.debrisAudio.currentTime = 0;
        this.debrisAudio.play().catch(() => {});
      } catch (e) {}
    }
    this.init();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(140, now);
      osc.frequency.exponentialRampToValueAtTime(30, now + 1.2);

      gain.gain.setValueAtTime(0.35, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 1.5);

      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start(now);
      osc.stop(now + 1.6);

      const bufferSize = this.ctx.sampleRate * 1.8;
      const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
      const output = noiseBuffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = (Math.random() * 2 - 1) * Math.exp(-i / (this.ctx.sampleRate * 0.4));
      }
      const noise = this.ctx.createBufferSource();
      noise.buffer = noiseBuffer;

      const filter = this.ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.setValueAtTime(450, now);
      filter.frequency.linearRampToValueAtTime(80, now + 1.2);

      const noiseGain = this.ctx.createGain();
      noiseGain.gain.setValueAtTime(0.3, now);
      noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 1.4);

      noise.connect(filter);
      filter.connect(noiseGain);
      noiseGain.connect(this.ctx.destination);

      noise.start(now);
      noise.stop(now + 1.8);
    } catch (e) {
      console.warn("Explosion audio error:", e);
    }
  }

  /**
   * Atmospheric Re-entry Breach Alarm
   */
  playReentryAlarm() {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = "sawtooth";
      osc.frequency.setValueAtTime(1200, now);
      osc.frequency.linearRampToValueAtTime(350, now + 0.5);

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.55);

      osc.connect(gain);
      gain.connect(this.ctx.destination);

      osc.start(now);
      osc.stop(now + 0.6);
    } catch (e) {
      console.warn("Reentry alarm error:", e);
    }
  }

  /**
   * Deep Space Ambient Drone
   */
  startAmbientHum() {
    if (this.isMuted || this.isAmbientPlaying) return;
    this.init();
    if (!this.ctx) return;

    try {
      const now = this.ctx.currentTime;
      this.ambientOsc1 = this.ctx.createOscillator();
      this.ambientOsc2 = this.ctx.createOscillator();
      this.ambientGain = this.ctx.createGain();

      this.ambientOsc1.type = "sine";
      this.ambientOsc1.frequency.setValueAtTime(55, now);

      this.ambientOsc2.type = "sine";
      this.ambientOsc2.frequency.setValueAtTime(110.5, now);

      const filter = this.ctx.createBiquadFilter();
      filter.type = "lowpass";
      filter.frequency.setValueAtTime(180, now);

      this.ambientGain.gain.setValueAtTime(0.001, now);
      this.ambientGain.gain.linearRampToValueAtTime(0.025, now + 2.0);

      this.ambientOsc1.connect(filter);
      this.ambientOsc2.connect(filter);
      filter.connect(this.ambientGain);
      this.ambientGain.connect(this.ctx.destination);

      this.ambientOsc1.start();
      this.ambientOsc2.start();
      this.isAmbientPlaying = true;
    } catch (e) {
      console.warn("Ambient hum error:", e);
    }
  }

  stopAmbientHum() {
    if (!this.ambientPlaying) return;
    try {
      if (this.ambientGain && this.ctx) {
        this.ambientGain.gain.linearRampToValueAtTime(0.0001, this.ctx.currentTime + 0.5);
        setTimeout(() => {
          if (this.ambientOsc1) this.ambientOsc1.stop();
          if (this.ambientOsc2) this.ambientOsc2.stop();
          this.isAmbientPlaying = false;
        }, 500);
      }
    } catch (e) {
      this.isAmbientPlaying = false;
    }
  }
}

export const audio = new AudioEngine();
