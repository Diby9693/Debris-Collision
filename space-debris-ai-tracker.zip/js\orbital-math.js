/**
 * ORBITAL MECHANICS & KEPLERIAN PROPAGATION ENGINE
 * Binary Hacks 4.0 - PS-07
 */

import { CONFIG } from './config.js';

export class OrbitalMath {
  /**
   * Solves Kepler's Equation M = E - e*sin(E) for Eccentric Anomaly E
   * using Newton-Raphson method with rapid quadratic convergence.
   */
  static solveKepler(M, e, tolerance = 1e-7, maxIter = 25) {
    // Normalize M to [0, 2*PI]
    M = M % (2 * Math.PI);
    if (M < 0) M += 2 * Math.PI;

    // Initial estimate for E
    let E = e > 0.8 ? Math.PI : M;

    for (let iter = 0; iter < maxIter; iter++) {
      const f = E - e * Math.sin(E) - M;
      if (Math.abs(f) < tolerance) break;
      const fPrime = 1 - e * Math.cos(E);
      E = E - f / fPrime;
    }

    return E;
  }

  /**
   * Propagates orbital state vector for a given object at elapsed time.
   * Universal alias supporting both delta seconds and epoch timestamps.
   */
  static propagateKepler(orbit, timeOrDelta = 0, gstAngleRad = 0) {
    let deltaSec = typeof timeOrDelta === 'number' ? timeOrDelta : 0;
    if (deltaSec > 1000000000) {
      // Millisecond epoch timestamp passed
      deltaSec = (deltaSec / 1000) % 86164;
    }
    return this.propagateOrbit(orbit, deltaSec, gstAngleRad);
  }

  /**
   * Propagates orbital state vector [x, y, z] and velocity [vx, vy, vz]
   * for a given object at elapsed time t (seconds) from epoch.
   */
  static propagateOrbit(orbit, deltaSeconds = 0, gstAngleRad = 0) {
    const mu = CONFIG.EARTH_MU; // km^3/s^2
    const a = orbit.semiMajorAxisKm;
    const e = orbit.eccentricity;
    const i = (orbit.inclinationDeg * Math.PI) / 180;
    const omega = (orbit.argPeriapsisDeg * Math.PI) / 180;
    const raan = (orbit.raanDeg * Math.PI) / 180;

    // Mean motion n = sqrt(mu / a^3) in radians/sec
    const n = Math.sqrt(mu / Math.pow(a, 3));

    // Current Mean Anomaly M
    const M0 = (orbit.meanAnomalyDeg * Math.PI) / 180;
    const M = M0 + n * deltaSeconds;

    // Solve for Eccentric Anomaly E
    const E = this.solveKepler(M, e);

    // Position in Perifocal (orbital plane) coordinate system
    const Px = a * (Math.cos(E) - e);
    const Py = a * Math.sqrt(1 - e * e) * Math.sin(E);
    const r = a * (1 - e * Math.cos(E)); // radius magnitude in km

    // Velocity in Perifocal plane
    const h = Math.sqrt(mu * a * (1 - e * e)); // specific angular momentum
    const sinNu = (a * Math.sqrt(1 - e * e) * Math.sin(E)) / r;
    const cosNu = (a * (Math.cos(E) - e)) / r;
    const Vpx = -(mu / h) * sinNu;
    const Vpy = (mu / h) * (e + cosNu);

    // Orbital speed magnitude (Vis-viva equation: v = sqrt(mu * (2/r - 1/a)))
    const velocityMagnitudeKmS = Math.sqrt(Math.max(0, mu * (2 / r - 1 / a)));

    // Transform from Perifocal to Earth-Centered Inertial (ECI) frame
    // Transformation components via 3-1-3 Euler rotation
    const cosO = Math.cos(raan);
    const sinO = Math.sin(raan);
    const cosi = Math.cos(i);
    const sini = Math.sin(i);
    const cosw = Math.cos(omega);
    const sinw = Math.sin(omega);

    const P11 = cosO * cosw - sinO * sinw * cosi;
    const P12 = -cosO * sinw - sinO * cosw * cosi;
    const P21 = sinO * cosw + cosO * sinw * cosi;
    const P22 = -sinO * sinw + cosO * cosw * cosi;
    const P31 = sinw * sini;
    const P32 = cosw * sini;

    // ECI Coordinates (in km)
    const eciX = P11 * Px + P12 * Py;
    const eciY = P21 * Px + P22 * Py;
    const eciZ = P31 * Px + P32 * Py;

    // ECI Velocity vectors (in km/s)
    const vx = P11 * Vpx + P12 * Vpy;
    const vy = P21 * Vpx + P22 * Vpy;
    const vz = P31 * Vpx + P32 * Vpy;

    // Convert ECI to 3D Scene units
    // (Note: in Three.js standard, Y is UP, X is RIGHT, Z is FORWARD)
    const scale = CONFIG.SCENE.KM_TO_3D_SCALE;
    const scenePos = {
      x: eciX * scale,
      y: eciZ * scale, // Map Z (North Pole) to 3D Y-axis
      z: -eciY * scale
    };

    // Calculate Geodetic Coordinates: Latitude, Longitude, Altitude
    const altitudeKm = Math.max(0, r - CONFIG.EARTH_RADIUS_KM);
    
    // Declination / Latitude in degrees
    const latRad = Math.atan2(eciZ, Math.sqrt(eciX * eciX + eciY * eciY));
    const latitudeDeg = (latRad * 180) / Math.PI;

    // Right ascension & Greenwich Sidereal Time adjustment for Longitude
    const alphaRad = Math.atan2(eciY, eciX);
    let lonRad = alphaRad - gstAngleRad;
    // Normalize to [-PI, +PI]
    lonRad = Math.atan2(Math.sin(lonRad), Math.cos(lonRad));
    const longitudeDeg = (lonRad * 180) / Math.PI;

    // Relativistic & Aerodynamic speed metrics
    const speedOfLightRatio = velocityMagnitudeKmS / CONFIG.SPEED_OF_LIGHT_KMS;
    const machNumber = velocityMagnitudeKmS / CONFIG.SPEED_OF_SOUND_KMS;
    const velocityKmH = velocityMagnitudeKmS * 3600;

    // Orbital Period in minutes: T = 2*PI * sqrt(a^3 / mu) / 60
    const periodMinutes = (2 * Math.PI * Math.sqrt(Math.pow(a, 3) / mu)) / 60;

    // Apogee and Perigee altitudes (km)
    const perigeeKm = a * (1 - e) - CONFIG.EARTH_RADIUS_KM;
    const apogeeKm = a * (1 + e) - CONFIG.EARTH_RADIUS_KM;

    // Velocity direction unit vector (Heading / flight path direction in ECI)
    const vMag = velocityMagnitudeKmS;
    const dirEci = vMag > 0 ? { x: vx / vMag, y: vy / vMag, z: vz / vMag } : { x: 0, y: 0, z: 0 };
    const dirScene = {
      x: dirEci.x,
      y: dirEci.z,
      z: -dirEci.y
    };

    // Flight Path Angle (angle between velocity vector and local horizontal)
    // gamma = asin((r . v) / (r * v))
    const rDotV = (eciX * vx + eciY * vy + eciZ * vz);
    const flightPathAngleDeg = (Math.asin(Math.max(-1, Math.min(1, rDotV / (r * vMag)))) * 180) / Math.PI;

    // Atmospheric Re-entry Risk Analysis (Below 160 km Karman/Decay barrier)
    const isReentryImminent = altitudeKm < 160;
    const isDecayingOrbit = perigeeKm < 180;
    // Estimated atmospheric drag heat index (W/cm^2 approx based on Sutton-Graves relation)
    const atmosphericHeatIndex = isReentryImminent ? Math.min(100, Math.pow((160 - altitudeKm) / 60, 2) * 100) : 0;

    return {
      eciPos: { x: eciX, y: eciY, z: eciZ },
      eciVel: { vx, vy, vz },
      dirScene,
      scenePos,
      radiusKm: r,
      altitudeKm,
      latitudeDeg,
      longitudeDeg,
      velocityKmS: velocityMagnitudeKmS,
      velocityKmH,
      machNumber,
      speedOfLightRatio,
      flightPathAngleDeg,
      isReentryImminent,
      isDecayingOrbit,
      atmosphericHeatIndex,
      periodMinutes,
      apogeeKm,
      perigeeKm
    };
  }

  /**
   * Generates a 3D Polyline / Points array representing the complete elliptical orbit
   * for Three.js LineLoop visualization.
   */
  static generateOrbitPathPoints(orbit, segments = 120) {
    const points = [];
    const mu = CONFIG.EARTH_MU;
    const a = orbit.semiMajorAxisKm;
    const e = orbit.eccentricity;
    const i = (orbit.inclinationDeg * Math.PI) / 180;
    const omega = (orbit.argPeriapsisDeg * Math.PI) / 180;
    const raan = (orbit.raanDeg * Math.PI) / 180;
    const scale = CONFIG.SCENE.KM_TO_3D_SCALE;

    const cosO = Math.cos(raan);
    const sinO = Math.sin(raan);
    const cosi = Math.cos(i);
    const sini = Math.sin(i);
    const cosw = Math.cos(omega);
    const sinw = Math.sin(omega);

    const P11 = cosO * cosw - sinO * sinw * cosi;
    const P12 = -cosO * sinw - sinO * cosw * cosi;
    const P21 = sinO * cosw + cosO * sinw * cosi;
    const P22 = -sinO * sinw + cosO * cosw * cosi;
    const P31 = sinw * sini;
    const P32 = cosw * sini;

    for (let j = 0; j <= segments; j++) {
      const E = (j / segments) * 2 * Math.PI;
      const Px = a * (Math.cos(E) - e);
      const Py = a * Math.sqrt(1 - e * e) * Math.sin(E);

      const eciX = P11 * Px + P12 * Py;
      const eciY = P21 * Px + P22 * Py;
      const eciZ = P31 * Px + P32 * Py;

      points.push({
        x: eciX * scale,
        y: eciZ * scale,
        z: -eciY * scale
      });
    }

    return points;
  }

  /**
   * Calculates Euclidean distance between two 3D positions in km
   */
  static calculateDistanceKm(posA, posB) {
    const dx = posA.x - posB.x;
    const dy = posA.y - posB.y;
    const dz = posA.z - posB.z;
    return Math.sqrt(dx * dx + dy * dy + dz * dz);
  }

  /**
   * Formats numbers into high-tech mission control readout strings
   */
  static formatTelemetry(val, decimals = 2, unit = "") {
    if (val === undefined || isNaN(val)) return `-- ${unit}`;
    return `${val.toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals })} ${unit}`.trim();
  }

  /**
   * Formats speed of light fraction in scientific or micro-fraction format
   */
  static formatSpeedOfLight(ratio) {
    if (!ratio || isNaN(ratio)) return "0.00000 c";
    // For orbital speed ~7.8 km/s, ratio is ~0.000026 c (or 2.60e-5 c)
    return `${(ratio * 100).toFixed(4)}% c (${ratio.toExponential(2)} c)`;
  }
}
