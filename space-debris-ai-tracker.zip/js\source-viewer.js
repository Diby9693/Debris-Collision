/**
 * IN-APP SOURCE CODE VIEWER & BACKEND CURSOR ACCESS
 * Binary Hacks 4.0 - PS-07
 * Hidden from main visible HUD, accessible via Cursor Right-Click, Double-Click or F2 Hotkey!
 */

export class SourceCodeViewer {
  constructor() {
    this.files = [
      { name: "index.html", path: "index.html", lang: "html" },
      { name: "styles.css", path: "css/styles.css", lang: "css" },
      { name: "main.js", path: "js/main.js", lang: "javascript" },
      { name: "earth-3d.js", path: "js/earth-3d.js", lang: "javascript" },
      { name: "orbital-math.js", path: "js/orbital-math.js", lang: "javascript" },
      { name: "ai-predictor.js", path: "js/ai-predictor.js", lang: "javascript" },
      { name: "data-source.js", path: "js/data-source.js", lang: "javascript" },
      { name: "ui-controller.js", path: "js/ui-controller.js", lang: "javascript" },
      { name: "audio-fx.js", path: "js/audio-fx.js", lang: "javascript" },
      { name: "config.js", path: "js/config.js", lang: "javascript" }
    ];

    this.activeFile = this.files[0];
    this.cachedContents = {};

    this.dom = {
      modal: document.getElementById('source-code-modal'),
      btnClose: document.getElementById('btn-close-source-modal'),
      fileTabs: document.getElementById('source-file-tabs'),
      codeDisplay: document.getElementById('source-code-content'),
      currentFileName: document.getElementById('source-current-file'),
      btnCopy: document.getElementById('btn-copy-code'),

      // Cursor Context Menu
      contextMenu: document.getElementById('cursor-context-menu'),
      ctxViewSource: document.getElementById('ctx-view-source'),
      ctxFocusMoon: document.getElementById('ctx-focus-moon'),
      ctxResetCam: document.getElementById('ctx-reset-cam'),
      ctxTriggerCollision: document.getElementById('ctx-trigger-collision')
    };

    this.init();
  }

  init() {
    // Modal buttons
    if (this.dom.btnClose) {
      this.dom.btnClose.addEventListener('click', () => this.close());
    }
    if (this.dom.btnCopy) {
      this.dom.btnCopy.addEventListener('click', () => this.copyCurrentCode());
    }

    // 1. CURSOR RIGHT-CLICK CONTEXT MENU
    window.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      this.openContextMenu(e.clientX, e.clientY);
    });

    // Dismiss context menu on left click anywhere
    window.addEventListener('click', (e) => {
      if (!e.target.closest('#cursor-context-menu')) {
        this.closeContextMenu();
      }
    });

    // Context Menu Actions
    if (this.dom.ctxViewSource) {
      this.dom.ctxViewSource.addEventListener('click', () => {
        this.closeContextMenu();
        this.open();
      });
    }

    if (this.dom.ctxFocusMoon) {
      this.dom.ctxFocusMoon.addEventListener('click', () => {
        this.closeContextMenu();
        if (window.SpaceApp && window.SpaceApp.earth3d) {
          window.SpaceApp.earth3d.setCameraPreset('moon');
        }
      });
    }

    if (this.dom.ctxResetCam) {
      this.dom.ctxResetCam.addEventListener('click', () => {
        this.closeContextMenu();
        if (window.SpaceApp && window.SpaceApp.earth3d) {
          window.SpaceApp.earth3d.setCameraPreset('default');
        }
      });
    }

    if (this.dom.ctxTriggerCollision) {
      this.dom.ctxTriggerCollision.addEventListener('click', () => {
        this.closeContextMenu();
        if (window.SpaceApp && window.SpaceApp.ui) {
          window.SpaceApp.ui.simulateCollisionEvent();
        }
      });
    }

    // 2. DOUBLE-CLICK RADAR LOGO SHORTCUT
    const radarLogo = document.querySelector('.radar-icon');
    if (radarLogo) {
      radarLogo.addEventListener('dblclick', () => this.open());
    }

    // 3. KEYBOARD SHORTCUT (F2 or Ctrl+Shift+S)
    window.addEventListener('keydown', (e) => {
      if (e.key === 'F2' || (e.ctrlKey && e.shiftKey && e.key.toLowerCase() === 's')) {
        e.preventDefault();
        this.open();
      }
      if (e.key === 'Escape') {
        this.close();
        this.closeContextMenu();
      }
    });

    this.renderTabs();
  }

  openContextMenu(x, y) {
    if (!this.dom.contextMenu) return;

    // Adjust position to stay inside viewport
    const menuWidth = 230;
    const menuHeight = 160;
    const posX = Math.min(x, window.innerWidth - menuWidth - 10);
    const posY = Math.min(y, window.innerHeight - menuHeight - 10);

    this.dom.contextMenu.style.left = `${posX}px`;
    this.dom.contextMenu.style.top = `${posY}px`;
    this.dom.contextMenu.classList.remove('hidden');
  }

  closeContextMenu() {
    if (this.dom.contextMenu) {
      this.dom.contextMenu.classList.add('hidden');
    }
  }

  open() {
    if (this.dom.modal) {
      this.dom.modal.classList.remove('hidden');
      this.loadFile(this.activeFile);
    }
  }

  close() {
    if (this.dom.modal) {
      this.dom.modal.classList.add('hidden');
    }
  }

  renderTabs() {
    if (!this.dom.fileTabs) return;
    this.dom.fileTabs.innerHTML = '';

    this.files.forEach(file => {
      const tab = document.createElement('button');
      tab.className = `source-tab ${this.activeFile.path === file.path ? 'active' : ''}`;
      tab.textContent = file.name;
      tab.addEventListener('click', () => {
        document.querySelectorAll('.source-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        this.loadFile(file);
      });
      this.dom.fileTabs.appendChild(tab);
    });
  }

  async loadFile(file) {
    this.activeFile = file;
    if (this.dom.currentFileName) {
      this.dom.currentFileName.textContent = `${file.name} (${file.lang.toUpperCase()})`;
    }

    if (this.cachedContents[file.path]) {
      this.displayCode(this.cachedContents[file.path]);
      return;
    }

    if (this.dom.codeDisplay) {
      this.dom.codeDisplay.textContent = `// Loading ${file.name}...`;
    }

    try {
      const response = await fetch(file.path);
      if (response.ok) {
        const text = await response.text();
        this.cachedContents[file.path] = text;
        this.displayCode(text);
      } else {
        this.dom.codeDisplay.textContent = `// Error loading ${file.path}: HTTP ${response.status}`;
      }
    } catch (err) {
      this.dom.codeDisplay.textContent = `// Error loading file: ${err.message}`;
    }
  }

  displayCode(code) {
    if (!this.dom.codeDisplay) return;
    const lines = code.split('\n');
    const numbered = lines.map((line, idx) => {
      const lineNum = (idx + 1).toString().padStart(4, ' ');
      return `${lineNum} | ${line}`;
    }).join('\n');

    this.dom.codeDisplay.textContent = numbered;
  }

  copyCurrentCode() {
    const rawCode = this.cachedContents[this.activeFile.path];
    if (rawCode) {
      navigator.clipboard.writeText(rawCode).then(() => {
        if (this.dom.btnCopy) {
          const original = this.dom.btnCopy.textContent;
          this.dom.btnCopy.textContent = "✅ COPIED TO CLIPBOARD!";
          setTimeout(() => {
            this.dom.btnCopy.textContent = original;
          }, 1500);
        }
      });
    }
  }
}
