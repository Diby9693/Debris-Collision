/**
 * SYSTEM BOOTSTRAP & MAIN ORCHESTRATION ENGINE
 * Binary Hacks 4.0 - PS-07
 * AI-Powered Space Debris Tracking & Collision Risk Prediction
 */

import { CONFIG } from './config.js';
import { generateOrbitalCatalog } from './data-source.js';
import { Earth3D } from './earth-3d.js';
import { UIController } from './ui-controller.js';
import { AIPredictor } from './ai-predictor.js';
import { audio } from './audio-fx.js';
import { SourceCodeViewer } from './source-viewer.js';
import { AIAssistant } from './ai-assistant.js';

class SpaceDebrisApp {
  constructor() {
    this.container = document.getElementById('canvas-container');
    this.orbitalCatalog = [];
    this.selectedObject = null;
    this.selectedObjectProp = null;

    // Simulation Timing - Default to 20x for visible continuous orbital motion!
    this.simDeltaSeconds = 0;
    this.timeWarpFactor = 20; // 20x cinematic speed so objects visibly move smoothly across the globe!
    this.lastTimestamp = performance.now();
    this.gstAngleRad = 0; // Greenwich Sidereal Time rotation angle

    // Subsystems
    this.earth3d = null;
    this.ui = null;
    this.sourceViewer = null;
    this.aiAssistant = null;

    // Conjunction Scan Interval Counter
    this.scanTickCounter = 0;
  }

  init() {
    console.log("%c[AEROSPACE ORBITAL DEFENSE SYSTEM INITIALIZING]", "color: #00f0ff; font-weight: bold; font-size: 14px;");

    // 1. Generate full catalog of satellites & debris
    this.orbitalCatalog = generateOrbitalCatalog(1250);

    // 2. Initialize 3D Engine
    this.earth3d = new Earth3D(this.container, (obj, prop) => {
      this.onObjectSelected(obj, prop);
    });
    this.earth3d.loadObjects(this.orbitalCatalog);

    // 3. Initialize UI & Mission Control
    this.ui = new UIController(this);
    this.ui.updateOverviewStats(this.orbitalCatalog);
    this.ui.renderObjectsList();

    // 3b. Generate Multi-Horizon Collision Timetable (1 Hour to 1 Year, 14 Horizons)
    this.forecastEvents = AIPredictor.generateMultiHorizonForecast(this.orbitalCatalog, Date.now());
    this.ui.initForecast(this.forecastEvents);

    // 4. Initialize Source Code Viewer & AI Copilot
    this.sourceViewer = new SourceCodeViewer();
    this.aiAssistant = new AIAssistant(this);

    // Check for saved theme
    try {
      const savedTheme = localStorage.getItem('astro_theme');
      if (savedTheme === 'light') {
        this.ui.toggleTheme();
      }
    } catch (e) {}

    // 5. Default Selected Spacecraft (Cartosat-2C: prime high-risk target!)
    const initialTarget = this.orbitalCatalog.find(o => o.noradId === 41607) || this.orbitalCatalog[0];
    this.earth3d.selectObject(initialTarget);

    // 6. Start Master Simulation Loop
    requestAnimationFrame(this.animate.bind(this));

    // Audio cue
    setTimeout(() => {
      audio.playRadarPing();
    }, 1000);
  }

  setTimeWarp(factor) {
    this.timeWarpFactor = factor;
  }

  onObjectSelected(obj, prop) {
    this.selectedObject = obj;
    this.selectedObjectProp = prop;
    this.ui.updateTelemetryHUD(obj, prop);
    this.evaluateTargetConjunctions();
    this.updateProximityRadar();
  }

  updateProximityRadar() {
    if (!this.selectedObject || !this.selectedObjectProp || !this.earth3d || !this.earth3d.objectPropCache) return;
    const nearestThreats = AIPredictor.getNearestThreatsForObject(
      this.selectedObject,
      this.selectedObjectProp,
      this.orbitalCatalog,
      this.earth3d.objectPropCache,
      4
    );
    this.ui.renderProximityRadar(nearestThreats);
  }

  evaluateTargetConjunctions() {
    if (!this.selectedObject || !this.selectedObjectProp) return;

    // Screen current target against all objects in scene
    const conjunctions = AIPredictor.evaluateConjunctions(
      this.selectedObject,
      this.selectedObjectProp,
      this.orbitalCatalog,
      this.earth3d.objectPropCache
    );

    this.ui.updateConjunctionWarning(conjunctions);

    if (conjunctions.length > 0) {
      const topRisk = conjunctions[0];
      const threatIdx = this.orbitalCatalog.indexOf(topRisk.threatObject);
      const threatProp = this.earth3d.objectPropCache[threatIdx];

      if (threatProp) {
        // Draw 3D threat orbit line and connecting laser vector
        this.earth3d.drawOrbitLine(topRisk.threatObject, true);
        this.earth3d.showConjunctionLaser(this.selectedObjectProp.scenePos, threatProp.scenePos);
      }
    } else {
      this.earth3d.hideConjunctionLaser();
    }
  }

  animate(nowTimestamp) {
    requestAnimationFrame(this.animate.bind(this));

    const deltaMs = nowTimestamp - this.lastTimestamp;
    this.lastTimestamp = nowTimestamp;

    // Accumulate simulation time
    const stepSeconds = (deltaMs / 1000) * this.timeWarpFactor;
    this.simDeltaSeconds += stepSeconds;

    // Update Greenwich Sidereal Time (Earth spin)
    // ~360 degrees per 86164 seconds
    this.gstAngleRad += (stepSeconds * (2 * Math.PI / 86164));

    // 1. Update 3D Positions of 1,200+ space objects
    this.earth3d.updateObjectPositions(this.simDeltaSeconds, this.gstAngleRad);

    // 2. Update Selected Object Telemetry Readouts
    if (this.selectedObject) {
      const idx = this.orbitalCatalog.indexOf(this.selectedObject);
      if (idx !== -1 && this.earth3d.objectPropCache[idx]) {
        this.selectedObjectProp = this.earth3d.objectPropCache[idx];
        this.ui.updateTelemetryHUD(this.selectedObject, this.selectedObjectProp);
      }
    }

    // 3. Periodic AI Conjunction Check & Proximity Radar (every 25 frames)
    this.scanTickCounter++;
    if (this.scanTickCounter >= 25) {
      this.scanTickCounter = 0;
      this.evaluateTargetConjunctions();
      this.updateProximityRadar();
    }

    // 4. Update Live Ticking Countdown Clocks on Collision Timetable
    this.ui.updateTimetableCountdowns(stepSeconds > 0 ? stepSeconds : (deltaMs / 1000));

    // 5. Update Clocks (UTC, IST, Julian Date)
    this.ui.updateClocks();

    // 5. Render 3D Frame
    this.earth3d.render();
  }
}

// Boot application upon DOM ready
window.addEventListener('DOMContentLoaded', () => {
  window.audio = audio;
  window.SpaceApp = new SpaceDebrisApp();
  window.SpaceApp.init();
});
