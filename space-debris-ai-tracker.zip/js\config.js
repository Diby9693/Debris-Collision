/**
 * AI-POWERED SPACE DEBRIS TRACKING & COLLISION RISK PREDICTION
 * Binary Hacks 4.0 - PS-07 Configuration & Constants
 */

export const CONFIG = {
  // Physical & Astronomical Constants
  EARTH_RADIUS_KM: 6371.0,               // Mean Earth radius in km
  EARTH_MU: 398600.4418,                 // Standard gravitational parameter of Earth (km^3/s^2)
  SPEED_OF_LIGHT_KMS: 299792.458,        // Speed of light in vacuum (km/s)
  SPEED_OF_SOUND_KMS: 0.343,             // Speed of sound at sea level (km/s)
  EARTH_ROTATION_RATE_DEG_SEC: 0.004178, // Earth rotation speed (~360 deg / 86164s)
  EARTH_TILT_DEG: 23.44,                 // Earth axial tilt in degrees

  // 3D Visualization Scene Scale
  SCENE: {
    EARTH_RADIUS_3D: 5.0,                // 5 Three.js units = 6371 km
    KM_TO_3D_SCALE: 5.0 / 6371.0,        // Conversion multiplier from km to 3D units
    CAMERA_INITIAL_POS: [0, 8, 18],
    STAR_COUNT: 2500,
    DEBRIS_PARTICLE_SIZE: 0.08,
    SATELLITE_SCALE: 0.14
  },

  // Orbital Zones Classification (km above surface)
  ORBIT_ZONES: {
    LEO: { min: 160, max: 2000, name: "Low Earth Orbit (LEO)", color: "#00f0ff" },
    MEO: { min: 2000, max: 35786, name: "Medium Earth Orbit (MEO)", color: "#38bdf8" },
    GEO: { min: 35786 - 500, max: 35786 + 500, name: "Geostationary Orbit (GEO)", color: "#c084fc" },
    HEO: { min: 36286, max: 80000, name: "High / Highly Elliptical Orbit", color: "#f472b6" }
  },

  // Object Classifications & Theme Colors
  OBJECT_TYPES: {
    PAYLOAD: { id: "payload", label: "Active Satellite", color: 0x00f0ff, cssColor: "#00f0ff", hex: "#00f0ff" },
    ROCKET_BODY: { id: "rocket_body", label: "Spent Rocket Booster", color: 0xf59e0b, cssColor: "#f59e0b", hex: "#f59e0b" },
    DEBRIS: { id: "debris", label: "Debris Fragment", color: 0xff2a5f, cssColor: "#ff2a5f", hex: "#ff2a5f" },
    STATION: { id: "station", label: "Manned Space Station", color: 0x10b981, cssColor: "#10b981", hex: "#10b981" }
  },

  // Collision Risk Thresholds (Foster/Akella-Alfriend Conjunction Analysis)
  RISK_LEVELS: {
    CRITICAL: {
      name: "CRITICAL HAZARD",
      color: "#ff2a5f",
      thresholdProbability: 1e-2,      // > 1% collision probability
      thresholdMissDistanceKm: 1.0,    // < 1 km miss distance
      alarm: true
    },
    HIGH: {
      name: "HIGH RISK",
      color: "#f97316",
      thresholdProbability: 1e-4,
      thresholdMissDistanceKm: 5.0,
      alarm: false
    },
    MODERATE: {
      name: "MODERATE CONCERN",
      color: "#eab308",
      thresholdProbability: 1e-6,
      thresholdMissDistanceKm: 15.0,
      alarm: false
    },
    NOMINAL: {
      name: "NOMINAL / SAFE",
      color: "#10b981",
      thresholdProbability: 0,
      thresholdMissDistanceKm: 99999.0,
      alarm: false
    }
  },

  // Time Warp Acceleration Factors
  TIME_WARP_OPTIONS: [
    { label: "PAUSE", factor: 0 },
    { label: "1x (REAL)", factor: 1 },
    { label: "10x", factor: 10 },
    { label: "100x", factor: 100 },
    { label: "500x", factor: 500 },
    { label: "1000x", factor: 1000 }
  ],

  // Multi-Horizon Conjunction Time Windows (Requested by User)
  TIME_HORIZONS: [
    { id: "1h", label: "1 HOUR", seconds: 3600, labelLong: "Next 1 Hour" },
    { id: "2h", label: "2 HOURS", seconds: 7200, labelLong: "Next 2 Hours" },
    { id: "4h", label: "4 HOURS", seconds: 14400, labelLong: "Next 4 Hours" },
    { id: "6h", label: "6 HOURS", seconds: 21600, labelLong: "Next 6 Hours" },
    { id: "12h", label: "12 HOURS", seconds: 43200, labelLong: "Next 12 Hours" },
    { id: "24h", label: "24 HOURS", seconds: 86400, labelLong: "Next 24 Hours (1 Day)" },
    { id: "2d", label: "2 DAYS", seconds: 172800, labelLong: "Next 2 Days" },
    { id: "4d", label: "4 DAYS", seconds: 345600, labelLong: "Next 4 Days" },
    { id: "10d", label: "10 DAYS", seconds: 864000, labelLong: "Next 10 Days" },
    { id: "1m", label: "1 MONTH", seconds: 2592000, labelLong: "Next 1 Month (30 Days)" },
    { id: "3m", label: "3 MONTHS", seconds: 7776000, labelLong: "Next 3 Months (90 Days)" },
    { id: "6m", label: "6 MONTHS", seconds: 15552000, labelLong: "Next 6 Months (180 Days)" },
    { id: "9m", label: "9 MONTHS", seconds: 23328000, labelLong: "Next 9 Months (270 Days)" },
    { id: "1y", label: "1 YEAR", seconds: 31536000, labelLong: "Next 1 Year (365 Days)" }
  ]
};
