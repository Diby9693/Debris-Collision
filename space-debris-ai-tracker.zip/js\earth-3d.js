/**
 * ULTRA-REALISTIC 3D EARTH & ORBITAL VISUALIZER (HIGH-FIDELITY)
 * Binary Hacks 4.0 - PS-07
 * Features:
 * - Ultra-Crisp 4096x2048 High-Definition Earth Map with 16x Anisotropic Filtering
 * - Highly Realistic Procedural 3D Models (Solar cell grids, Gold MLI Foil, ISS Modules, Rocket Nozzles, Asteroid Cratering)
 * - Directional Vectors & Flow Toggle (ON / OFF)
 * - Object Layers Toggle (Show/Hide Satellites, Rockets, Debris)
 * - Adjustable Earth Rotation Speed (Calm & Majestic Default)
 */

import { CONFIG } from './config.js';
import { OrbitalMath } from './orbital-math.js';
import { audio } from './audio-fx.js';

export class Earth3D {
  constructor(containerElement, onObjectSelectedCallback) {
    this.container = containerElement;
    this.onObjectSelected = onObjectSelectedCallback;

    this.scene = null;
    this.camera = null;
    this.renderer = null;
    this.controls = null;
    this.raycaster = new THREE.Raycaster();
    this.mouse = new THREE.Vector2();

    // Earth System
    this.earthGroup = null;
    this.earthMesh = null;
    this.cloudsMesh = null;
    this.atmosphereMesh = null;
    this.sunLight = null;
    this.starfield = null;
    this.starGroup = null;
    this.starMaterial = null;
    this.brightStarsPoints = null;
    this.brightStarsMat = null;

    // Moon System
    this.moonGroup = null;
    this.moonMesh = null;
    this.moonOrbitAngle = 0.5;
    this.moonDistance = 38.0; // Scaled deep space vantage distance

    // Earth Rotation Controls (Calm, majestic default speed)
    this.autoRotateEarth = true;
    this.baseEarthSpeed = 0.00075;
    this.earthSpinMultiplier = 1.0;

    // Feature Toggles
    this.showDirectionVectors = true;
    this.showAllObjects = true;
    this.showPayloads = true;
    this.showRockets = true;
    this.showDebris = true;

    // Spacecraft & Debris
    this.objectsList = [];
    this.objectPropCache = [];
    this.objectMeshes = [];
    this.instancedDebris = null;
    this.debrisRotations = [];

    // Trajectory & Vectors
    this.selectedOrbitLine = null;
    this.threatOrbitLine = null;
    this.conjunctionLaserLine = null;
    this.conjunctionSphereMesh = null;
    this.targetReticleMesh = null;
    this.velocityArrowHelper = null;
    this.orbitPhotonParticles = null;
    this.orbitPhotonPoints = [];

    // Re-entry & Explosion
    this.reentryFireballGroup = new THREE.Group();
    this.activeExplosions = [];

    // Camera Tracking
    this.trackedObject = null;
    this.isTracking = false;

    this.init();
  }

  init() {
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;

    // 1. Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x010206);

    // 2. Camera with crisp logarithmic depth
    this.camera = new THREE.PerspectiveCamera(45, width / height, 0.05, 2500);
    this.camera.position.set(...CONFIG.SCENE.CAMERA_INITIAL_POS);

    // 3. Renderer with maximum anisotropic filtering
    this.renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: "high-performance" });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.25;
    this.container.appendChild(this.renderer.domElement);

    // 4. OrbitControls with smooth close zoom
    if (THREE.OrbitControls) {
      this.controls = new THREE.OrbitControls(this.camera, this.renderer.domElement);
      this.controls.enableDamping = true;
      this.controls.dampingFactor = 0.06;
      this.controls.minDistance = 5.25;
      this.controls.maxDistance = 220.0; // Allow zooming out to view the Moon!
      this.controls.rotateSpeed = 0.65;
    }

    this.setupLighting();
    this.createStarfield();
    this.createEarthSystem();
    this.createMoonSystem();
    this.createVisualAids();
    this.scene.add(this.reentryFireballGroup);

    window.addEventListener('resize', this.onWindowResize.bind(this));
    this.renderer.domElement.addEventListener('pointerdown', this.onPointerDown.bind(this));
  }

  setupLighting() {
    // Deep space ambient fill
    const ambientLight = new THREE.AmbientLight(0x182236, 1.3);
    this.scene.add(ambientLight);

    // Main Solar Directional Light
    this.sunLight = new THREE.DirectionalLight(0xffffff, 2.7);
    this.sunLight.position.set(45, 18, 35);
    this.scene.add(this.sunLight);

    // Atmospheric scattering rim light
    const rimLight = new THREE.DirectionalLight(0x00f0ff, 0.45);
    rimLight.position.set(-35, -12, -25);
    this.scene.add(rimLight);
  }

  createEarthSystem() {
    this.earthGroup = new THREE.Group();
    this.earthGroup.rotation.z = (CONFIG.EARTH_TILT_DEG * Math.PI) / 180;
    this.scene.add(this.earthGroup);

    const radius = CONFIG.SCENE.EARTH_RADIUS_3D;
    const segments = 96; // Higher polygon count for pristine spherical smoothness

    // Ultra-High Resolution 4096x2048 Procedural Earth Texture
    const earthCanvas = this.generateUltraHDEarthTexture();
    const earthTexture = new THREE.CanvasTexture(earthCanvas);
    earthTexture.minFilter = THREE.LinearMipmapLinearFilter;
    earthTexture.magFilter = THREE.LinearFilter;
    earthTexture.anisotropy = this.renderer.capabilities.getMaxAnisotropy() || 16;

    // Specular Ocean Water Map
    const specularCanvas = this.generateOceanSpecularMap();
    const specularTexture = new THREE.CanvasTexture(specularCanvas);

    // Online NASA High-Res Fallback / Enhancement
    const textureLoader = new THREE.TextureLoader();
    textureLoader.load(
      'https://raw.githubusercontent.com/mrdoob/three.js/master/examples/textures/planets/earth_atmos_2048.jpg',
      (tex) => {
        if (this.earthMesh) {
          tex.anisotropy = 16;
          this.earthMesh.material.map = tex;
          this.earthMesh.material.needsUpdate = true;
        }
      },
      undefined,
      () => { /* Instant high-def offline fallback */ }
    );

    // Earth Sphere Mesh
    const earthGeo = new THREE.SphereGeometry(radius, segments, segments);
    const earthMat = new THREE.MeshPhongMaterial({
      map: earthTexture,
      specularMap: specularTexture,
      shininess: 32,
      specular: new THREE.Color(0x336699)
    });
    this.earthMesh = new THREE.Mesh(earthGeo, earthMat);
    this.earthGroup.add(this.earthMesh);

    // Rotating Clouds Layer
    const cloudCanvas = this.generateHDCloudTexture();
    const cloudTexture = new THREE.CanvasTexture(cloudCanvas);
    cloudTexture.anisotropy = 8;
    const cloudGeo = new THREE.SphereGeometry(radius * 1.012, segments, segments);
    const cloudMat = new THREE.MeshLambertMaterial({
      map: cloudTexture,
      transparent: true,
      opacity: 0.42,
      blending: THREE.AdditiveBlending
    });
    this.cloudsMesh = new THREE.Mesh(cloudGeo, cloudMat);
    this.earthGroup.add(this.cloudsMesh);

    // Atmospheric Corona Scattering Glow
    const atmosphereGeo = new THREE.SphereGeometry(radius * 1.14, segments, segments);
    const atmosphereMat = new THREE.ShaderMaterial({
      vertexShader: `
        varying vec3 vNormal;
        void main() {
          vNormal = normalize(normalMatrix * normal);
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        varying vec3 vNormal;
        void main() {
          float intensity = pow(0.66 - dot(vNormal, vec3(0.0, 0.0, 1.0)), 2.4);
          gl_FragColor = vec4(0.0, 0.72, 1.0, 1.0) * intensity * 1.35;
        }
      `,
      blending: THREE.AdditiveBlending,
      side: THREE.BackSide,
      transparent: true
    });
    this.atmosphereMesh = new THREE.Mesh(atmosphereGeo, atmosphereMat);
    this.earthGroup.add(this.atmosphereMesh);
  }

  createMoonSystem() {
    this.moonGroup = new THREE.Group();
    this.scene.add(this.moonGroup);

    // 1. Lunar Orbit Trajectory Ribbon
    const orbitPoints = [];
    const segments = 120;
    const incRad = (5.14 * Math.PI) / 180;
    for (let i = 0; i <= segments; i++) {
      const theta = (i / segments) * Math.PI * 2;
      const x = Math.cos(theta) * this.moonDistance;
      const z = Math.sin(theta) * this.moonDistance;
      const y = Math.sin(theta) * (this.moonDistance * Math.sin(incRad));
      orbitPoints.push(new THREE.Vector3(x, y, z));
    }
    const moonOrbitGeo = new THREE.BufferGeometry().setFromPoints(orbitPoints);
    const moonOrbitMat = new THREE.LineBasicMaterial({
      color: 0x94a3b8,
      transparent: true,
      opacity: 0.25,
      linewidth: 1
    });
    const moonOrbitLine = new THREE.LineLoop(moonOrbitGeo, moonOrbitMat);
    this.moonGroup.add(moonOrbitLine);

    // 2. High-Detail Procedural Cratered Moon Sphere
    const moonRadius = 1.36; // ~1/4th Earth scale
    const moonCanvas = this.generateMoonCanvasTexture();
    const moonTexture = new THREE.CanvasTexture(moonCanvas);
    moonTexture.anisotropy = 8;

    const moonGeo = new THREE.SphereGeometry(moonRadius, 48, 48);
    const moonMat = new THREE.MeshStandardMaterial({
      map: moonTexture,
      roughness: 0.9,
      metalness: 0.05
    });

    this.moonMesh = new THREE.Mesh(moonGeo, moonMat);
    this.moonMesh.userData = { isMoon: true };

    const initX = Math.cos(this.moonOrbitAngle) * this.moonDistance;
    const initZ = Math.sin(this.moonOrbitAngle) * this.moonDistance;
    const initY = Math.sin(this.moonOrbitAngle) * (this.moonDistance * Math.sin(incRad));
    this.moonMesh.position.set(initX, initY, initZ);
    this.moonGroup.add(this.moonMesh);
  }

  generateMoonCanvasTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 512;
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = '#b0b5bc';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = '#656b73';
    const maria = [
      { x: 380, y: 190, rx: 95, ry: 75 },
      { x: 500, y: 160, rx: 110, ry: 85 },
      { x: 280, y: 220, rx: 140, ry: 110 },
      { x: 420, y: 310, rx: 80, ry: 65 },
      { x: 620, y: 220, rx: 70, ry: 60 },
      { x: 320, y: 130, rx: 85, ry: 65 }
    ];

    maria.forEach(m => {
      ctx.beginPath();
      ctx.ellipse(m.x, m.y, m.rx, m.ry, Math.random() * 0.4, 0, Math.PI * 2);
      ctx.fill();
    });

    ctx.fillStyle = '#ffffff';
    for (let c = 0; c < 240; c++) {
      const cx = Math.random() * canvas.width;
      const cy = Math.random() * canvas.height;
      const r = 1 + Math.random() * 5;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = 'rgba(40, 45, 52, 0.4)';
      ctx.beginPath();
      ctx.arc(cx + 1, cy + 1, r * 0.7, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#ffffff';
    }

    return canvas;
  }

  selectMoon() {
    const moonObj = {
      id: "NATURAL-MOON-01",
      noradId: 1,
      name: "The Moon (Luna / Chandrama)",
      type: "station",
      agency: "Natural Satellite of Earth",
      country: "Solar System",
      launchYear: -4500000000,
      massKg: 7.342e22,
      crossSectionM2: 9.48e12,
      status: "Tidally Locked Natural Orbit",
      description: "Earth's sole natural satellite. Surface gravity: 1.62 m/s² (0.166g). Semi-major axis: 384,400 km. Host to Apollo and Chandrayaan-3 landing sites.",
      orbit: {
        semiMajorAxisKm: 384400.0,
        eccentricity: 0.0549,
        inclinationDeg: 5.14,
        raanDeg: 125.08,
        argPeriapsisDeg: 318.15,
        meanAnomalyDeg: 115.36
      }
    };

    const moonProp = {
      eciPos: { x: this.moonMesh.position.x * (6371 / 5), y: -this.moonMesh.position.z * (6371 / 5), z: this.moonMesh.position.y * (6371 / 5) },
      eciVel: { vx: 0.98, vy: 0.12, vz: 0.28 },
      dirScene: { x: -Math.sin(this.moonOrbitAngle), y: 0, z: Math.cos(this.moonOrbitAngle) },
      scenePos: this.moonMesh.position,
      radiusKm: 384400.0,
      altitudeKm: 378029.0,
      latitudeDeg: 5.14,
      longitudeDeg: (this.moonOrbitAngle * 180 / Math.PI) % 360,
      velocityKmS: 1.022,
      velocityKmH: 3679.2,
      machNumber: 2.98,
      speedOfLightRatio: 1.022 / 299792.458,
      flightPathAngleDeg: 0.0,
      isReentryImminent: false,
      isDecayingOrbit: false,
      periodMinutes: 39343.0,
      apogeeKm: 405400.0,
      perigeeKm: 362600.0
    };

    this.selectObject(moonObj);
    audio.playSpaceStationAmbience();

    if (this.onObjectSelected) {
      this.onObjectSelected(moonObj, moonProp);
    }
  }

  /**
   * ============================================================
   * ISRO CHANDRAYAAN-4 LUNAR MISSION SIMULATOR (HIGH-FIDELITY)
   * ============================================================
   * Staging Sequence:
   * 1. LVM3 Lift-off from SDSC SHAR (Sriharikota) with twin S200 booster plumes
   * 2. S200 Solid Booster Jettison & C25 Cryogenic ignition
   * 3. Earth Parking Orbit Insertion (180 km altitude) & Solar Array deploy
   * 4. Trans-Lunar Injection (TLI) Burn toward Lunar Transfer Trajectory
   * 5. Cislunar Cruise across deep space with spacecraft tracking camera
   * 6. Lunar Orbit Insertion (LOI) Retro-burn into Moon capture orbit
   * 7. Vikram Lander Powered Descent with green Laser Altimeter terrain scan
   * 8. Lunar South Pole Soft Touchdown & Pragyan Rover deployment
   */
  startChandrayaanMission(onTelemetryCallback) {
    this.stopChandrayaanMission();
    this.chandrayaanActive = true;
    this.chandrayaanTelemetryCb = onTelemetryCallback;
    this.chandrayaanStartTime = performance.now();

    this.chandrayaanGroup = new THREE.Group();

    // 1. LVM3 Core Body (White metallic cylinder with ISRO branding)
    const coreMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, metalness: 0.8, roughness: 0.25 });
    const coreGeo = new THREE.CylinderGeometry(0.12, 0.12, 0.9, 20);
    this.lvm3Core = new THREE.Mesh(coreGeo, coreMat);
    this.chandrayaanGroup.add(this.lvm3Core);

    // 2. Twin S200 Solid Rocket Boosters
    const boosterMat = new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 0.7, roughness: 0.3 });
    const boosterGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.75, 16);
    this.leftBooster = new THREE.Mesh(boosterGeo, boosterMat);
    this.leftBooster.position.set(-0.18, -0.05, 0);
    this.rightBooster = new THREE.Mesh(boosterGeo, boosterMat);
    this.rightBooster.position.set(0.18, -0.05, 0);
    this.chandrayaanGroup.add(this.leftBooster);
    this.chandrayaanGroup.add(this.rightBooster);

    // 3. Rocket Exhaust Fire Plumes
    const fireMat = new THREE.MeshBasicMaterial({ color: 0xff7700, transparent: true, opacity: 0.9, blending: THREE.AdditiveBlending });
    const plumeGeo = new THREE.ConeGeometry(0.08, 0.35, 12, 1, true);
    this.plume1 = new THREE.Mesh(plumeGeo, fireMat);
    this.plume1.rotation.x = Math.PI;
    this.plume1.position.set(-0.18, -0.55, 0);
    this.plume2 = new THREE.Mesh(plumeGeo, fireMat);
    this.plume2.rotation.x = Math.PI;
    this.plume2.position.set(0.18, -0.55, 0);
    this.plumeCore = new THREE.Mesh(plumeGeo, fireMat);
    this.plumeCore.rotation.x = Math.PI;
    this.plumeCore.position.set(0, -0.6, 0);
    this.chandrayaanGroup.add(this.plume1);
    this.chandrayaanGroup.add(this.plume2);
    this.chandrayaanGroup.add(this.plumeCore);

    // 4. Vikram Lander (Gold MLI foil bus + emerald laser altimeter)
    const landerMat = new THREE.MeshStandardMaterial({ color: 0xffb703, metalness: 0.95, roughness: 0.15 });
    const landerGeo = new THREE.BoxGeometry(0.14, 0.12, 0.14);
    this.vikramLander = new THREE.Mesh(landerGeo, landerMat);
    this.vikramLander.position.set(0, 0.52, 0);

    const landerSolarMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, emissive: 0x0369a1, metalness: 0.7, roughness: 0.2 });
    const panelGeo = new THREE.BoxGeometry(0.18, 0.08, 0.005);
    const pLeft = new THREE.Mesh(panelGeo, landerSolarMat);
    pLeft.position.set(-0.15, 0, 0);
    const pRight = new THREE.Mesh(panelGeo, landerSolarMat);
    pRight.position.set(0.15, 0, 0);
    this.vikramLander.add(pLeft);
    this.vikramLander.add(pRight);

    // Green Laser Altimeter Sensor Cone
    const altimeterGeo = new THREE.ConeGeometry(0.25, 0.9, 16, 1, true);
    const altimeterMat = new THREE.MeshBasicMaterial({
      color: 0x10b981,
      transparent: true,
      opacity: 0.35,
      blending: THREE.AdditiveBlending,
      side: THREE.DoubleSide,
      depthWrite: false
    });
    this.laserAltimeter = new THREE.Mesh(altimeterGeo, altimeterMat);
    this.laserAltimeter.rotation.x = Math.PI;
    this.laserAltimeter.position.set(0, -0.5, 0);
    this.laserAltimeter.visible = false;
    this.vikramLander.add(this.laserAltimeter);

    this.chandrayaanGroup.add(this.vikramLander);

    // Initial position: Sriharikota launch pad
    const initR = 5.08;
    this.chandrayaanGroup.position.set(initR * 0.95, 0.8, 0.3);
    this.scene.add(this.chandrayaanGroup);

    audio.playThrusterBurn();
  }

  stopChandrayaanMission() {
    this.chandrayaanActive = false;
    if (this.chandrayaanGroup) {
      this.scene.remove(this.chandrayaanGroup);
      this.chandrayaanGroup = null;
    }
    if (this.controls) {
      this.controls.target.set(0, 0, 0);
    }
  }

  updateChandrayaanStep() {
    if (!this.chandrayaanActive || !this.chandrayaanGroup || !this.moonMesh) return;
    const elapsedSec = (performance.now() - this.chandrayaanStartTime) * 0.001;
    const TOTAL_MISSION_TIME = 42.0;

    const t = Math.min(1.0, elapsedSec / TOTAL_MISSION_TIME);
    const moonPos = this.moonMesh.position.clone();
    const lunarSouthPole = moonPos.clone().add(new THREE.Vector3(0, -1.36, 0.1));

    let stageIdx = 0;
    let stageName = "LVM3 LIFTOFF";
    let altKm = 0;
    let velKmS = 1.2;
    let distMoonKm = 384400;
    let fuelPct = 100;
    let statusText = "S200 Twin Solid Boosters Firing | Sriharikota Launch Site";

    if (t < 0.12) {
      // 1. LIFTOFF (0 - 5s)
      stageIdx = 0;
      stageName = "LVM3 LIFTOFF & ASCENT";
      const subT = t / 0.12;
      const r = 5.08 + subT * 1.2;
      this.chandrayaanGroup.position.set(r * 0.95, 0.8 + subT * 0.6, 0.3 + subT * 0.4);
      this.chandrayaanGroup.rotation.z = -subT * 0.4;
      altKm = subT * 85;
      velKmS = 1.2 + subT * 1.8;
      distMoonKm = 384400 - altKm;
      fuelPct = 95 - subT * 15;
      statusText = "Solid booster burn nominal. Passing Max-Q aerothermal pressure.";

      this.camera.position.lerp(new THREE.Vector3(this.chandrayaanGroup.position.x + 3.5, this.chandrayaanGroup.position.y + 1.2, this.chandrayaanGroup.position.z + 4), 0.08);
      if (this.controls) this.controls.target.copy(this.chandrayaanGroup.position);

    } else if (t < 0.22) {
      // 2. BOOSTER SEPARATION (5s - 9s)
      stageIdx = 1;
      stageName = "S200 BOOSTER JETTISON";
      const subT = (t - 0.12) / 0.10;
      if (this.leftBooster) this.leftBooster.position.x = -0.18 - subT * 0.8;
      if (this.rightBooster) this.rightBooster.position.x = 0.18 + subT * 0.8;
      if (this.plume1) this.plume1.visible = false;
      if (this.plume2) this.plume2.visible = false;
      if (this.plumeCore) this.plumeCore.scale.set(1.4, 1.4, 1.4);

      const r = 6.28 + subT * 0.8;
      this.chandrayaanGroup.position.set(r * 0.92, 1.4 + subT * 0.4, 0.7 + subT * 0.8);
      altKm = 85 + subT * 95;
      velKmS = 3.0 + subT * 4.6;
      distMoonKm = 384400 - altKm;
      fuelPct = 80 - subT * 12;
      statusText = "S200 Boosters successfully jettisoned. C25 Cryogenic upper stage ignited.";

    } else if (t < 0.35) {
      // 3. EARTH PARKING ORBIT (9s - 15s)
      stageIdx = 2;
      stageName = "EARTH PARKING ORBIT";
      const subT = (t - 0.22) / 0.13;
      if (this.lvm3Core) this.lvm3Core.visible = false;
      if (this.plumeCore) this.plumeCore.visible = false;

      const angle = 0.8 + subT * 1.5;
      const orbitR = 7.2;
      this.chandrayaanGroup.position.set(Math.cos(angle) * orbitR, Math.sin(angle) * orbitR * 0.3, Math.sin(angle) * orbitR);
      this.chandrayaanGroup.lookAt(0, 0, 0);
      altKm = 180 + subT * 20;
      velKmS = 7.6;
      distMoonKm = 384000;
      fuelPct = 68;
      statusText = "Parking orbit achieved (180x42000 km). Solar arrays deployed & generating power.";

    } else if (t < 0.48) {
      // 4. TRANS-LUNAR INJECTION (TLI) BURN (15s - 20s)
      stageIdx = 3;
      stageName = "TRANS-LUNAR INJECTION (TLI)";
      const subT = (t - 0.35) / 0.13;
      if (this.plumeCore) {
        this.plumeCore.visible = true;
        this.plumeCore.material.color.setHex(0x00f0ff);
      }
      const angle = 2.3 + subT * 0.8;
      const r = 7.2 + subT * 8.0;
      this.chandrayaanGroup.position.set(Math.cos(angle) * r, 1.5 + subT * 4.0, Math.sin(angle) * r);
      altKm = 200 + subT * 24000;
      velKmS = 10.45;
      distMoonKm = 384000 - subT * 60000;
      fuelPct = 52;
      statusText = "TLI thruster burn in progress. Escaping Earth gravity well into Lunar Transfer Trajectory.";

      this.camera.position.lerp(new THREE.Vector3(this.chandrayaanGroup.position.x + 5, this.chandrayaanGroup.position.y + 3, this.chandrayaanGroup.position.z + 8), 0.05);
      if (this.controls) this.controls.target.copy(this.chandrayaanGroup.position);

    } else if (t < 0.68) {
      // 5. CISLUNAR CRUISE (20s - 28s)
      stageIdx = 4;
      stageName = "CISLUNAR CRUISE TRAJECTORY";
      const subT = (t - 0.48) / 0.20;
      if (this.plumeCore) this.plumeCore.visible = false;

      const startP = new THREE.Vector3(-10, 5, 8);
      const midP = new THREE.Vector3(moonPos.x * 0.5, moonPos.y * 0.6 + 6, moonPos.z * 0.5);
      const targetP = moonPos.clone().add(new THREE.Vector3(-4, 2, -2));

      const oneMinusT = 1 - subT;
      this.chandrayaanGroup.position.x = oneMinusT * oneMinusT * startP.x + 2 * oneMinusT * subT * midP.x + subT * subT * targetP.x;
      this.chandrayaanGroup.position.y = oneMinusT * oneMinusT * startP.y + 2 * oneMinusT * subT * midP.y + subT * subT * targetP.y;
      this.chandrayaanGroup.position.z = oneMinusT * oneMinusT * startP.z + 2 * oneMinusT * subT * midP.z + subT * subT * targetP.z;
      this.chandrayaanGroup.lookAt(moonPos);

      altKm = 50000 + subT * 320000;
      velKmS = 1.8;
      distMoonKm = Math.round(324000 * (1 - subT) + 12000);
      fuelPct = 48;
      statusText = "Translunar coast phase. Star sensor attitude control locked on Moon.";

      this.camera.position.lerp(new THREE.Vector3(this.chandrayaanGroup.position.x + 4, this.chandrayaanGroup.position.y + 2, this.chandrayaanGroup.position.z + 6), 0.06);
      if (this.controls) this.controls.target.copy(this.chandrayaanGroup.position);

    } else if (t < 0.80) {
      // 6. LUNAR ORBIT INSERTION (LOI) (28s - 34s)
      stageIdx = 5;
      stageName = "LUNAR ORBIT INSERTION (LOI)";
      const subT = (t - 0.68) / 0.12;
      if (this.plumeCore) {
        this.plumeCore.visible = true;
        this.plumeCore.material.color.setHex(0xf59e0b);
      }
      const orbitAngle = subT * Math.PI * 1.5;
      const lunarOrbitR = 2.4;
      this.chandrayaanGroup.position.set(
        moonPos.x + Math.cos(orbitAngle) * lunarOrbitR,
        moonPos.y + Math.sin(orbitAngle) * 0.6,
        moonPos.z + Math.sin(orbitAngle) * lunarOrbitR
      );
      this.chandrayaanGroup.lookAt(moonPos);
      altKm = 100;
      velKmS = 1.68;
      distMoonKm = Math.round(150 * (1 - subT) + 30);
      fuelPct = 36;
      statusText = "Retro-propulsion burn firing. Spacecraft successfully captured into 100 km Lunar circular orbit.";

      this.camera.position.lerp(new THREE.Vector3(moonPos.x + 3.5, moonPos.y + 2.0, moonPos.z + 5.0), 0.08);
      if (this.controls) this.controls.target.copy(moonPos);

    } else if (t < 0.94) {
      // 7. POWERED DESCENT (34s - 39s)
      stageIdx = 6;
      stageName = "VIKRAM POWERED DESCENT";
      const subT = (t - 0.80) / 0.14;
      if (this.plumeCore) this.plumeCore.visible = false;
      if (this.laserAltimeter) {
        this.laserAltimeter.visible = true;
        this.laserAltimeter.material.opacity = 0.4 + 0.3 * Math.sin(performance.now() * 0.015);
      }

      const startHover = moonPos.clone().add(new THREE.Vector3(0, -2.2, 0.4));
      this.chandrayaanGroup.position.lerpVectors(startHover, lunarSouthPole, subT);
      this.chandrayaanGroup.rotation.set(0, 0, 0);

      altKm = +(30 * (1 - subT)).toFixed(2);
      velKmS = +(1.68 * (1 - subT)).toFixed(2);
      distMoonKm = altKm;
      fuelPct = 24 - subT * 10;
      statusText = "Lander Hazard Detection & Avoidance camera active. Green Laser Altimeter scanning South Pole terrain.";

      this.camera.position.lerp(new THREE.Vector3(lunarSouthPole.x + 2.2, lunarSouthPole.y + 0.8, lunarSouthPole.z + 3.2), 0.1);
      if (this.controls) this.controls.target.copy(lunarSouthPole);

    } else {
      // 8. LUNAR TOUCHDOWN & PRAGYAN ROVER (39s - 42s+)
      stageIdx = 7;
      stageName = "SOUTH POLE TOUCHDOWN SUCCESS";
      this.chandrayaanGroup.position.copy(lunarSouthPole);
      if (this.laserAltimeter) this.laserAltimeter.visible = false;
      altKm = 0.0;
      velKmS = 0.0;
      distMoonKm = 0.0;
      fuelPct = 14;
      statusText = "TOUCHDOWN CONFIRMED! Vikram Lander safely perched at Lunar South Pole. Pragyan Rover deployed on the regolith.";

      this.camera.position.lerp(new THREE.Vector3(lunarSouthPole.x + 1.8, lunarSouthPole.y + 0.5, lunarSouthPole.z + 2.4), 0.08);
      if (this.controls) this.controls.target.copy(lunarSouthPole);
    }

    if (this.chandrayaanTelemetryCb) {
      this.chandrayaanTelemetryCb({
        stageIndex: stageIdx,
        stageName,
        altitudeKm: altKm,
        velocityKmS: velKmS,
        distanceToMoonKm: distMoonKm,
        fuelPercent: Math.round(fuelPct),
        status: statusText,
        progressPercent: Math.round(t * 100)
      });
    }
  }

  /**
   * Ultra-HD 4096x2048 Canvas Earth Map Generator
   * Features detailed coastlines, topography relief, mountain biomes, polar ice caps, and night city light clusters.
   */
  generateUltraHDEarthTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 4096;
    canvas.height = 2048;
    const ctx = canvas.getContext('2d');

    // Deep Ocean gradient with bathymetry shading
    const oceanGrad = ctx.createLinearGradient(0, 0, 0, canvas.height);
    oceanGrad.addColorStop(0, '#0a2140');
    oceanGrad.addColorStop(0.2, '#071830');
    oceanGrad.addColorStop(0.5, '#041022');
    oceanGrad.addColorStop(0.8, '#071830');
    oceanGrad.addColorStop(1, '#0a2140');
    ctx.fillStyle = oceanGrad;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Continental shelf coastal shallow cyan glow
    ctx.lineWidth = 14;
    ctx.strokeStyle = 'rgba(12, 64, 88, 0.45)';

    const drawPoly = (coords, fillStyle, stroke = true) => {
      ctx.beginPath();
      coords.forEach(([x, y], idx) => {
        const px = (x / 360 + 0.5) * canvas.width;
        const py = (-y / 180 + 0.5) * canvas.height;
        if (idx === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      });
      ctx.closePath();
      ctx.fillStyle = fillStyle;
      ctx.fill();
      if (stroke) ctx.stroke();
    };

    // A. Eurasia / Asia / Europe / Middle East
    drawPoly([
      [ -10, 36 ], [ 5, 42 ], [ 15, 38 ], [ 30, 31 ], [ 35, 36 ], [ 42, 42 ],
      [ 55, 35 ], [ 60, 25 ], [ 70, 22 ], [ 75, 12 ], [ 80, 8 ], [ 85, 20 ],
      [ 100, 15 ], [ 105, 5 ], [ 110, 20 ], [ 120, 25 ], [ 130, 35 ], [ 142, 52 ],
      [ 150, 60 ], [ 130, 72 ], [ 80, 75 ], [ 40, 72 ], [ 20, 70 ], [ 5, 62 ],
      [ -5, 58 ], [ -10, 44 ]
    ], '#184732');

    // B. Detailed India Subcontinent & Himalayas
    drawPoly([
      [ 68, 24 ], [ 72, 31 ], [ 76, 36 ], [ 80, 32 ], [ 88, 28 ], [ 92, 24 ],
      [ 86, 20 ], [ 82, 16 ], [ 80, 12 ], [ 77, 8 ], [ 74, 14 ], [ 70, 18 ]
    ], '#256344');

    // C. Africa Continent & Sahara Desert
    drawPoly([
      [ -17, 15 ], [ -12, 28 ], [ -5, 36 ], [ 12, 37 ], [ 25, 32 ], [ 34, 31 ],
      [ 38, 28 ], [ 43, 12 ], [ 51, 10 ], [ 42, 2 ], [ 40, -10 ], [ 35, -24 ],
      [ 28, -34 ], [ 18, -34 ], [ 12, -18 ], [ 8, 4 ], [ -5, 5 ], [ -17, 15 ]
    ], '#36593b');
    // Sahara desert golden tone
    drawPoly([
      [ -10, 20 ], [ 0, 30 ], [ 25, 30 ], [ 32, 22 ], [ 28, 16 ], [ 10, 16 ], [ -10, 20 ]
    ], '#735933', false);

    // D. North America & Central America
    drawPoly([
      [ -168, 65 ], [ -145, 60 ], [ -125, 50 ], [ -122, 35 ], [ -115, 30 ],
      [ -105, 20 ], [ -95, 18 ], [ -85, 22 ], [ -80, 25 ], [ -75, 35 ],
      [ -65, 45 ], [ -55, 50 ], [ -65, 60 ], [ -85, 68 ], [ -120, 72 ],
      [ -168, 70 ]
    ], '#1e4834');

    // E. South America (Amazon Basin & Andes)
    drawPoly([
      [ -80, 10 ], [ -70, 12 ], [ -55, 5 ], [ -35, -5 ], [ -38, -18 ],
      [ -48, -28 ], [ -58, -40 ], [ -68, -55 ], [ -75, -50 ], [ -78, -35 ],
      [ -81, -15 ], [ -80, 0 ]
    ], '#194a2b');

    // F. Australia
    drawPoly([
      [ 114, -22 ], [ 122, -16 ], [ 135, -12 ], [ 142, -10 ], [ 152, -24 ],
      [ 150, -36 ], [ 138, -38 ], [ 125, -34 ], [ 114, -30 ]
    ], '#665330');

    // G. Polar Ice Caps (Arctic & Antarctica)
    ctx.fillStyle = '#e8f4f8';
    // Antarctica (South pole ice sheet)
    ctx.fillRect(0, canvas.height * 0.92, canvas.width, canvas.height * 0.08);
    // Greenland Ice
    drawPoly([[ -50, 75 ], [ -30, 80 ], [ -20, 75 ], [ -40, 62 ]], '#f0f9ff', false);

    // H. Coordinate Navigation Grid Overlay (Subtle)
    ctx.strokeStyle = 'rgba(0, 240, 255, 0.09)';
    ctx.lineWidth = 1;
    for (let lat = -80; lat <= 80; lat += 20) {
      const y = (-lat / 180 + 0.5) * canvas.height;
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(canvas.width, y);
      ctx.stroke();
    }
    for (let lon = -180; lon <= 180; lon += 30) {
      const x = (lon / 360 + 0.5) * canvas.width;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, canvas.height);
      ctx.stroke();
    }

    // I. High-Resolution City Night Lights
    ctx.fillStyle = 'rgba(255, 235, 150, 0.85)';
    for (let i = 0; i < 1500; i++) {
      const rx = Math.random() * canvas.width;
      const ry = 0.22 * canvas.height + Math.random() * 0.55 * canvas.height;
      const size = Math.random() > 0.85 ? 3 : (Math.random() > 0.5 ? 2 : 1);
      ctx.fillRect(rx, ry, size, size);
    }

    return canvas;
  }

  generateOceanSpecularMap() {
    const canvas = document.createElement('canvas');
    canvas.width = 1024;
    canvas.height = 512;
    const ctx = canvas.getContext('2d');
    // Oceans reflect white/silver shine, continents remain dark matte
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    return canvas;
  }

  generateHDCloudTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 2048;
    canvas.height = 1024;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = 'rgba(0,0,0,0)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
    for (let i = 0; i < 260; i++) {
      const x = Math.random() * canvas.width;
      const y = Math.random() * canvas.height;
      const rad = 35 + Math.random() * 95;
      const grad = ctx.createRadialGradient(x, y, 0, x, y, rad);
      grad.addColorStop(0, 'rgba(255, 255, 255, 0.55)');
      grad.addColorStop(0.6, 'rgba(255, 255, 255, 0.18)');
      grad.addColorStop(1, 'rgba(255, 255, 255, 0)');
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(x, y, rad, 0, Math.PI * 2);
      ctx.fill();
    }
    return canvas;
  }

  generateGlowStarTexture() {
    const canvas = document.createElement('canvas');
    canvas.width = 64;
    canvas.height = 64;
    const ctx = canvas.getContext('2d');
    const grad = ctx.createRadialGradient(32, 32, 0, 32, 32, 32);
    grad.addColorStop(0.0, 'rgba(255, 255, 255, 1.0)');
    grad.addColorStop(0.2, 'rgba(220, 240, 255, 0.95)');
    grad.addColorStop(0.5, 'rgba(130, 190, 255, 0.45)');
    grad.addColorStop(0.8, 'rgba(70, 130, 255, 0.12)');
    grad.addColorStop(1.0, 'rgba(0, 0, 0, 0.0)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 64, 64);
    const texture = new THREE.CanvasTexture(canvas);
    return texture;
  }

  createStarfield() {
    this.starGroup = new THREE.Group();
    this.scene.add(this.starGroup);

    // ==========================================
    // 1. PRIMARY GPU TWINKLING STARFIELD (3,500 Stars)
    // ==========================================
    const count = 3500;
    const starGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const phases = new Float32Array(count);
    const speeds = new Float32Array(count);
    const sizes = new Float32Array(count);

    for (let i = 0; i < count; i++) {
      const r = 260 + Math.random() * 280;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);

      positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      positions[i * 3 + 2] = r * Math.cos(phi);

      // Star Spectral Class Colors (O, B, A, F, G, K, M)
      const roll = Math.random();
      if (roll > 0.85) {
        colors[i * 3] = 0.65; colors[i * 3 + 1] = 0.85; colors[i * 3 + 2] = 1.0; // Blue Giant / Rigel
      } else if (roll > 0.65) {
        colors[i * 3] = 1.0; colors[i * 3 + 1] = 0.92; colors[i * 3 + 2] = 0.72; // Solar Gold / Capella
      } else if (roll > 0.48) {
        colors[i * 3] = 1.0; colors[i * 3 + 1] = 0.68; colors[i * 3 + 2] = 0.48; // Red Giant / Betelgeuse
      } else {
        colors[i * 3] = 1.0; colors[i * 3 + 1] = 1.0; colors[i * 3 + 2] = 1.0; // Diamond White / Sirius
      }

      // Independent twinkling attributes per star
      phases[i] = Math.random() * Math.PI * 2;
      speeds[i] = 1.8 + Math.random() * 5.2; // Twinkle frequency
      sizes[i] = 3.5 + Math.random() * 4.5;  // Base point size
    }

    starGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    starGeo.setAttribute('aColor', new THREE.BufferAttribute(colors, 3));
    starGeo.setAttribute('aPhase', new THREE.BufferAttribute(phases, 1));
    starGeo.setAttribute('aSpeed', new THREE.BufferAttribute(speeds, 1));
    starGeo.setAttribute('aSize', new THREE.BufferAttribute(sizes, 1));

    // High-performance GPU Twinkling / Blinking Shader
    this.starMaterial = new THREE.ShaderMaterial({
      uniforms: {
        uTime: { value: 0 }
      },
      vertexShader: `
        attribute vec3 aColor;
        attribute float aPhase;
        attribute float aSpeed;
        attribute float aSize;
        varying vec3 vColor;
        varying float vAlpha;
        uniform float uTime;

        void main() {
          vColor = aColor;
          // Smooth sinusoidal twinkling oscillation
          float s = sin(uTime * aSpeed + aPhase);
          float twinkle = 0.5 + 0.5 * s;
          vAlpha = 0.35 + 0.65 * twinkle;

          vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
          float pSize = aSize * (0.8 + 0.6 * twinkle) * (360.0 / -mvPosition.z);
          // Clamp size between 2.5px and 28.0px for luminous clarity
          gl_PointSize = clamp(pSize, 2.5, 28.0);
          gl_Position = projectionMatrix * mvPosition;
        }
      `,
      fragmentShader: `
        precision highp float;
        varying vec3 vColor;
        varying float vAlpha;

        void main() {
          vec2 coord = gl_PointCoord - vec2(0.5);
          float dist = length(coord);
          if (dist > 0.5) discard;

          // Sparkling celestial diamond core with soft outer halo
          float core = 1.0 - smoothstep(0.0, 0.22, dist);
          float halo = 1.0 - smoothstep(0.12, 0.5, dist);
          float brightness = core * 1.8 + halo * 0.75;

          gl_FragColor = vec4(vColor * brightness, vAlpha);
        }
      `,
      transparent: true,
      blending: THREE.AdditiveBlending,
      depthWrite: false
    });

    this.starfield = new THREE.Points(starGeo, this.starMaterial);
    this.starGroup.add(this.starfield);

    // ==========================================
    // 2. SECONDARY CELESTIAL STARS (200 Pulsars & Major Constellations)
    // ==========================================
    const majorCount = 200;
    const majorGeo = new THREE.BufferGeometry();
    const majorPos = new Float32Array(majorCount * 3);
    const majorColors = new Float32Array(majorCount * 3);

    for (let i = 0; i < majorCount; i++) {
      const r = 280 + Math.random() * 200;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);

      majorPos[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      majorPos[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      majorPos[i * 3 + 2] = r * Math.cos(phi);

      const roll = Math.random();
      if (roll > 0.7) {
        majorColors[i * 3] = 0.5; majorColors[i * 3 + 1] = 0.85; majorColors[i * 3 + 2] = 1.0;
      } else if (roll > 0.4) {
        majorColors[i * 3] = 1.0; majorColors[i * 3 + 1] = 0.90; majorColors[i * 3 + 2] = 0.65;
      } else {
        majorColors[i * 3] = 1.0; majorColors[i * 3 + 1] = 1.0; majorColors[i * 3 + 2] = 1.0;
      }
    }

    majorGeo.setAttribute('position', new THREE.BufferAttribute(majorPos, 3));
    majorGeo.setAttribute('color', new THREE.BufferAttribute(majorColors, 3));

    const starSprite = this.generateGlowStarTexture();
    this.brightStarsMat = new THREE.PointsMaterial({
      size: 5.5,
      map: starSprite,
      vertexColors: true,
      transparent: true,
      opacity: 0.95,
      blending: THREE.AdditiveBlending,
      depthWrite: false
    });

    this.brightStarsPoints = new THREE.Points(majorGeo, this.brightStarsMat);
    this.starGroup.add(this.brightStarsPoints);
  }

  createVisualAids() {
    // 1. Target Reticle
    const ringGeo = new THREE.RingGeometry(0.28, 0.35, 32);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x00f0ff,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.9
    });
    this.targetReticleMesh = new THREE.Mesh(ringGeo, ringMat);
    this.targetReticleMesh.visible = false;
    this.scene.add(this.targetReticleMesh);

    // 2. 3D Velocity Heading Arrow
    const dir = new THREE.Vector3(1, 0, 0);
    const origin = new THREE.Vector3(0, 0, 0);
    this.velocityArrowHelper = new THREE.ArrowHelper(dir, origin, 1.35, 0x00ff99, 0.38, 0.2);
    this.velocityArrowHelper.visible = false;
    this.scene.add(this.velocityArrowHelper);

    // 3. Conjunction Laser Line
    const laserMat = new THREE.LineBasicMaterial({
      color: 0xff2a5f,
      linewidth: 3,
      transparent: true,
      opacity: 0.95
    });
    const laserGeo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(), new THREE.Vector3()]);
    this.conjunctionLaserLine = new THREE.Line(laserGeo, laserMat);
    this.conjunctionLaserLine.visible = false;
    this.scene.add(this.conjunctionLaserLine);

    // 4. Conjunction Hazard Wireframe Sphere
    const sphereGeo = new THREE.SphereGeometry(0.35, 16, 16);
    const sphereMat = new THREE.MeshBasicMaterial({
      color: 0xff2a5f,
      wireframe: true,
      transparent: true,
      opacity: 0.6
    });
    this.conjunctionSphereMesh = new THREE.Mesh(sphereGeo, sphereMat);
    this.conjunctionSphereMesh.visible = false;
    this.scene.add(this.conjunctionSphereMesh);
  }

  /**
   * Generates highly realistic 3D procedural models with solar panel cells, MLI foil, and antennas
   */
  createDetailedSatelliteMesh(obj) {
    const group = new THREE.Group();

    if (obj.type === CONFIG.OBJECT_TYPES.STATION.id) {
      // --- SPACE STATION (ISS / Tiangong) ---
      const moduleMat = new THREE.MeshStandardMaterial({ color: 0xdedede, metalness: 0.85, roughness: 0.25 });
      const trussMat = new THREE.MeshStandardMaterial({ color: 0x888888, metalness: 0.9, roughness: 0.3 });
      const solarMat = new THREE.MeshStandardMaterial({ color: 0x1d4ed8, emissive: 0x0a1d47, metalness: 0.6, roughness: 0.2 });

      // Core modules
      const coreGeo = new THREE.CylinderGeometry(0.07, 0.07, 0.55, 16);
      const core = new THREE.Mesh(coreGeo, moduleMat);
      core.rotation.z = Math.PI / 2;
      group.add(core);

      // Cupola Window
      const cupolaGeo = new THREE.SphereGeometry(0.04, 12, 12, 0, Math.PI * 2, 0, Math.PI / 2);
      const cupolaMat = new THREE.MeshBasicMaterial({ color: 0x00f0ff, transparent: true, opacity: 0.8 });
      const cupola = new THREE.Mesh(cupolaGeo, cupolaMat);
      cupola.position.set(0, 0.07, 0);
      group.add(cupola);

      // Main Integrated Truss Structure (ITS)
      const trussGeo = new THREE.BoxGeometry(0.04, 0.9, 0.04);
      const truss = new THREE.Mesh(trussGeo, trussMat);
      group.add(truss);

      // 4 Pairs of Solar Array Wings
      [-0.32, 0.32].forEach(yPos => {
        [-0.22, 0.22].forEach(xPos => {
          const panelGeo = new THREE.BoxGeometry(0.24, 0.14, 0.008);
          const panel = new THREE.Mesh(panelGeo, solarMat);
          panel.position.set(xPos, yPos, 0);
          group.add(panel);
        });
      });

    } else if (obj.type === CONFIG.OBJECT_TYPES.PAYLOAD.id) {
      // --- ACTIVE HYPER-REALISTIC SATELLITE (Cartosat, Starlink, Earth-Observation) ---
      const busMat = new THREE.MeshStandardMaterial({ color: 0xffb703, metalness: 0.95, roughness: 0.16 }); // High-reflectance Gold MLI Thermal Foil
      const solarMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, emissive: 0x075985, metalness: 0.75, roughness: 0.22 });
      const dishMat = new THREE.MeshStandardMaterial({ color: 0xe2e8f0, metalness: 0.7, roughness: 0.25 });
      const frameMat = new THREE.MeshStandardMaterial({ color: 0x1e293b, metalness: 0.9, roughness: 0.2 });

      // Main Satellite Bus
      const busGeo = new THREE.BoxGeometry(0.15, 0.15, 0.18);
      const bus = new THREE.Mesh(busGeo, busMat);
      group.add(bus);

      // Solar Panel Wings with structural frames & cell textures
      const wingGeo = new THREE.BoxGeometry(0.32, 0.11, 0.008);
      const leftWing = new THREE.Mesh(wingGeo, solarMat);
      leftWing.position.set(-0.28, 0, 0);
      group.add(leftWing);

      const rightWing = new THREE.Mesh(wingGeo, solarMat);
      rightWing.position.set(0.28, 0, 0);
      group.add(rightWing);

      // Dual High-Gain Parabolic Antennas
      const dishGeo = new THREE.ConeGeometry(0.08, 0.05, 16, 1, true);
      const dish = new THREE.Mesh(dishGeo, dishMat);
      dish.rotation.x = Math.PI / 2;
      dish.position.set(0, 0.1, 0.1);
      group.add(dish);

      // Rocket Thruster Bell
      const thrusterGeo = new THREE.ConeGeometry(0.04, 0.06, 12, 1, true);
      const thruster = new THREE.Mesh(thrusterGeo, frameMat);
      thruster.position.set(0, 0, -0.12);
      group.add(thruster);

      // --- EARTH-OBSERVING OPTICAL CAMERA & MULTISPECTRAL SENSOR POD ---
      const camPodGeo = new THREE.CylinderGeometry(0.038, 0.048, 0.1, 16);
      const camPodMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, metalness: 0.9, roughness: 0.2 });
      const camPod = new THREE.Mesh(camPodGeo, camPodMat);
      camPod.rotation.x = Math.PI / 2;
      camPod.position.set(0, -0.07, 0.09);
      group.add(camPod);

      // Optical Glass Lens (Glowing Cyan / Emerald)
      const lensGeo = new THREE.CircleGeometry(0.036, 16);
      const lensMat = new THREE.MeshBasicMaterial({ color: 0x00f0ff, side: THREE.DoubleSide });
      const lens = new THREE.Mesh(lensGeo, lensMat);
      lens.position.set(0, -0.07, 0.141);
      group.add(lens);

      // --- ACTIVE DOWNWARD SCANNING SENSOR LIGHT CONE (LIDAR / RADAR SWATH) ---
      const scanConeGeo = new THREE.ConeGeometry(0.65, 3.2, 24, 1, true);
      const scanConeMat = new THREE.MeshBasicMaterial({
        color: 0x00f0ff,
        transparent: true,
        opacity: 0.22,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide,
        depthWrite: false
      });
      const scanCone = new THREE.Mesh(scanConeGeo, scanConeMat);
      scanCone.rotation.x = -Math.PI / 2;
      scanCone.position.set(0, -0.07, 1.6);
      group.add(scanCone);

      // Ground Track Scan Swath Ring
      const swathGeo = new THREE.RingGeometry(0.60, 0.68, 32);
      const swathMat = new THREE.MeshBasicMaterial({
        color: 0x00f0ff,
        transparent: true,
        opacity: 0.45,
        blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide,
        depthWrite: false
      });
      const swathRing = new THREE.Mesh(swathGeo, swathMat);
      swathRing.position.set(0, -0.07, 3.19);
      group.add(swathRing);

      // Pulsing Anti-Collision Strobe LED Beacon
      const strobeGeo = new THREE.SphereGeometry(0.022, 8, 8);
      const strobeMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
      const strobeBeacon = new THREE.Mesh(strobeGeo, strobeMat);
      strobeBeacon.position.set(0, 0.12, -0.06);
      group.add(strobeBeacon);

      group.userData = { obj, scanCone, swathRing, strobeBeacon, isScanningSatellite: true };
      return group;

    } else if (obj.type === CONFIG.OBJECT_TYPES.ROCKET_BODY.id) {
      // --- ROCKET BOOSTER (Metallic cylinder + Interstage + Engine Bell) ---
      const stageMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, metalness: 0.75, roughness: 0.3 });
      const bellMat = new THREE.MeshStandardMaterial({ color: 0x262626, metalness: 0.95, roughness: 0.15 });

      const cylGeo = new THREE.CylinderGeometry(0.075, 0.075, 0.38, 20);
      const cyl = new THREE.Mesh(cylGeo, stageMat);
      group.add(cyl);

      const bellGeo = new THREE.ConeGeometry(0.07, 0.1, 16, 1, true);
      const bell = new THREE.Mesh(bellGeo, bellMat);
      bell.position.set(0, -0.23, 0);
      group.add(bell);

    } else {
      // --- AUTHENTIC SPACE DEBRIS FRAGMENT (Multi-tonal Titanium / MLI Gold / Charred / Bronze) ---
      const debrisPalettes = [
        { color: 0x94a3b8, metalness: 0.88, roughness: 0.28 }, // Weathered Titanium
        { color: 0xd97706, metalness: 0.94, roughness: 0.18 }, // Shredded Gold MLI Foil
        { color: 0x334155, metalness: 0.22, roughness: 0.85 }, // Charred Carbon Composite
        { color: 0xb45309, metalness: 0.78, roughness: 0.35 }  // Oxidized Bronze Bracket
      ];
      const palette = debrisPalettes[Math.floor(Math.random() * debrisPalettes.length)];
      const scrapMat = new THREE.MeshStandardMaterial({
        color: palette.color,
        roughness: palette.roughness,
        metalness: palette.metalness
      });
      const scrapGeo = new THREE.IcosahedronGeometry(0.1, 0);
      const scrap = new THREE.Mesh(scrapGeo, scrapMat);
      group.add(scrap);

      // Invisible generous hit sphere (radius 0.35) for instant touch & click detection
      const hitSphereGeo = new THREE.SphereGeometry(0.35, 8, 8);
      const hitSphereMat = new THREE.MeshBasicMaterial({ visible: false });
      const hitSphere = new THREE.Mesh(hitSphereGeo, hitSphereMat);
      group.add(hitSphere);
    }

    group.userData = { obj };
    return group;
  }

  loadObjects(objects) {
    this.objectsList = objects;

    const DETAILED_COUNT = Math.min(objects.length, 120);
    this.detailedObjects = objects.slice(0, DETAILED_COUNT);
    this.ambientObjects = objects.slice(DETAILED_COUNT);

    // 1. Create detailed 3D Meshes for primary spacecraft
    this.detailedObjects.forEach(obj => {
      const mesh = this.createDetailedSatelliteMesh(obj);
      this.scene.add(mesh);
      this.objectMeshes.push(mesh);

      this.debrisRotations.push({
        rx: (Math.random() - 0.5) * 0.04,
        ry: (Math.random() - 0.5) * 0.04,
        rz: (Math.random() - 0.5) * 0.04
      });
    });

    // 2. High-performance InstancedMesh for ambient debris with realistic multi-tonal space scrap materials
    const ambientCount = this.ambientObjects.length;
    if (ambientCount > 0) {
      const instGeo = new THREE.DodecahedronGeometry(CONFIG.SCENE.DEBRIS_PARTICLE_SIZE * 1.3, 0);
      const instMat = new THREE.MeshStandardMaterial({
        roughness: 0.65,
        metalness: 0.55
      });
      this.instancedDebris = new THREE.InstancedMesh(instGeo, instMat, ambientCount);
      this.instancedDebris.userData = { list: this.ambientObjects };

      // Realistic aerospace metallic colors
      const debrisColors = [
        new THREE.Color(0x94a3b8), // Titanium Gray
        new THREE.Color(0xcbd5e1), // Aluminum Sheet
        new THREE.Color(0xf59e0b), // Gold MLI Foil
        new THREE.Color(0xd97706), // Amber Thermal Insulation
        new THREE.Color(0x334155), // Charred Carbon Composite
        new THREE.Color(0xb45309)  // Oxidized Bronze Bracket
      ];
      for (let i = 0; i < ambientCount; i++) {
        const c = debrisColors[i % debrisColors.length];
        this.instancedDebris.setColorAt(i, c);
      }
      this.instancedDebris.instanceColor.needsUpdate = true;
      this.scene.add(this.instancedDebris);
    }
  }

  updateObjectPositions(simDeltaSeconds, gstAngleRad) {
    this.objectPropCache = [];

    // Propagate all orbits
    for (let i = 0; i < this.objectsList.length; i++) {
      const obj = this.objectsList[i];
      const prop = OrbitalMath.propagateOrbit(obj.orbit, simDeltaSeconds, gstAngleRad);
      this.objectPropCache.push(prop);

      // Update detailed 3D meshes
      if (i < this.objectMeshes.length) {
        const mesh = this.objectMeshes[i];
        if (mesh) {
          const p = prop.scenePos;
          mesh.position.set(p.x, p.y, p.z);

          // Apply visibility filters
          mesh.visible = this.showAllObjects && (
            (obj.type === CONFIG.OBJECT_TYPES.PAYLOAD.id && this.showPayloads) ||
            (obj.type === CONFIG.OBJECT_TYPES.STATION.id && this.showPayloads) ||
            (obj.type === CONFIG.OBJECT_TYPES.ROCKET_BODY.id && this.showRockets) ||
            (obj.type === CONFIG.OBJECT_TYPES.DEBRIS.id && this.showDebris)
          );

          // Orient satellite: Active satellites point camera & scanning light nadir to Earth center!
          if (mesh.userData && mesh.userData.isScanningSatellite) {
            mesh.lookAt(0, 0, 0);
          } else if (prop.dirScene && prop.velocityKmS > 0) {
            const targetPoint = new THREE.Vector3(p.x + prop.dirScene.x, p.y + prop.dirScene.y, p.z + prop.dirScene.z);
            mesh.lookAt(targetPoint);
          }

          // Tumbling rotation (only for unguided tumbling space debris)
          const rot = this.debrisRotations[i];
          if (rot && obj.type === CONFIG.OBJECT_TYPES.DEBRIS.id) {
            mesh.rotation.x += rot.rx;
            mesh.rotation.y += rot.ry;
          }

          // Atmospheric Re-entry Fireball Check
          if (prop.isReentryImminent) {
            this.triggerReentryPlasma(p);
          }
        }
      }
    }

    // Update ambient instanced debris
    if (this.instancedDebris && this.ambientObjects) {
      this.instancedDebris.visible = this.showAllObjects && this.showDebris;
      if (this.instancedDebris.visible) {
        const dummy = new THREE.Object3D();
        const offset = this.detailedObjects.length;
        for (let j = 0; j < this.ambientObjects.length; j++) {
          const prop = this.objectPropCache[offset + j];
          if (prop) {
            dummy.position.set(prop.scenePos.x, prop.scenePos.y, prop.scenePos.z);
            dummy.updateMatrix();
            this.instancedDebris.setMatrixAt(j, dummy.matrix);
          }
        }
        this.instancedDebris.instanceMatrix.needsUpdate = true;
      }
    }

    // Update Selected Object Reticle & 3D Velocity Arrow
    if (this.trackedObject) {
      const idx = this.objectsList.indexOf(this.trackedObject);
      if (idx !== -1 && this.objectPropCache[idx]) {
        const prop = this.objectPropCache[idx];
        const p = prop.scenePos;

        this.targetReticleMesh.position.set(p.x, p.y, p.z);
        this.targetReticleMesh.lookAt(this.camera.position);

        if (this.velocityArrowHelper) {
          if (this.showDirectionVectors && prop.dirScene) {
            const dirVec = new THREE.Vector3(prop.dirScene.x, prop.dirScene.y, prop.dirScene.z).normalize();
            this.velocityArrowHelper.position.set(p.x, p.y, p.z);
            this.velocityArrowHelper.setDirection(dirVec);
            this.velocityArrowHelper.visible = true;
          } else {
            this.velocityArrowHelper.visible = false;
          }
        }

        if (this.isTracking && this.controls) {
          const targetVec = new THREE.Vector3(p.x, p.y, p.z);
          this.controls.target.lerp(targetVec, 0.08);
        }
      }
    }

    // AUTOMATIC CONTINUOUS EARTH ROTATION (Adjusted speed)
    if (this.autoRotateEarth && this.earthGroup) {
      const currentSpeed = this.baseEarthSpeed * this.earthSpinMultiplier;
      this.earthGroup.rotation.y += currentSpeed;
      if (this.cloudsMesh) {
        this.cloudsMesh.rotation.y += currentSpeed * 0.4;
      }
    }

    // CONTINUOUS MOON ORBITAL REVOLUTION AROUND EARTH
    if (this.moonMesh) {
      const moonStep = (this.autoRotateEarth ? 0.00025 * this.earthSpinMultiplier : 0.0001);
      this.moonOrbitAngle += moonStep;
      const incRad = (5.14 * Math.PI) / 180;
      const mx = Math.cos(this.moonOrbitAngle) * this.moonDistance;
      const mz = Math.sin(this.moonOrbitAngle) * this.moonDistance;
      const my = Math.sin(this.moonOrbitAngle) * (this.moonDistance * Math.sin(incRad));
      this.moonMesh.position.set(mx, my, mz);
      // Tidal locking (faces Earth)
      this.moonMesh.rotation.y = this.moonOrbitAngle + Math.PI;
    }

    // Animate traveling photon pulses if direction is ON
    if (this.showDirectionVectors) {
      this.animateOrbitPhotons();
    } else if (this.orbitPhotonParticles) {
      this.orbitPhotonParticles.visible = false;
    }

    this.updateExplosions();
  }

  setEarthSpinMultiplier(multiplier) {
    this.earthSpinMultiplier = multiplier;
  }

  toggleDirectionVectors() {
    this.showDirectionVectors = !this.showDirectionVectors;
    if (this.velocityArrowHelper) {
      this.velocityArrowHelper.visible = this.showDirectionVectors;
    }
    if (this.orbitPhotonParticles) {
      this.orbitPhotonParticles.visible = this.showDirectionVectors;
    }
    return this.showDirectionVectors;
  }

  toggleAllObjects() {
    this.showAllObjects = !this.showAllObjects;
    return this.showAllObjects;
  }

  selectObject(obj) {
    this.trackedObject = obj;
    if (!obj) {
      this.targetReticleMesh.visible = false;
      if (this.velocityArrowHelper) this.velocityArrowHelper.visible = false;
      this.clearOrbitLine();
      return;
    }

    this.targetReticleMesh.visible = true;
    this.drawOrbitLine(obj);

    if (this.onObjectSelected) {
      const idx = this.objectsList.indexOf(obj);
      this.onObjectSelected(obj, this.objectPropCache[idx] || null);
    }
  }

  drawOrbitLine(obj, isThreat = false) {
    const points = OrbitalMath.generateOrbitPathPoints(obj.orbit, 140);
    const vectors = points.map(pt => new THREE.Vector3(pt.x, pt.y, pt.z));
    const geometry = new THREE.BufferGeometry().setFromPoints(vectors);

    const color = isThreat ? 0xff2a5f : (obj.type === CONFIG.OBJECT_TYPES.DEBRIS.id ? 0xf59e0b : 0x00f0ff);
    const material = new THREE.LineBasicMaterial({
      color,
      linewidth: 2,
      transparent: true,
      opacity: isThreat ? 0.75 : 0.95
    });

    if (isThreat) {
      if (this.threatOrbitLine) this.scene.remove(this.threatOrbitLine);
      this.threatOrbitLine = new THREE.LineLoop(geometry, material);
      this.scene.add(this.threatOrbitLine);
    } else {
      if (this.selectedOrbitLine) this.scene.remove(this.selectedOrbitLine);
      this.selectedOrbitLine = new THREE.LineLoop(geometry, material);
      this.scene.add(this.selectedOrbitLine);

      this.setupOrbitPhotons(vectors);
    }
  }

  setupOrbitPhotons(vectors) {
    if (this.orbitPhotonParticles) {
      this.scene.remove(this.orbitPhotonParticles);
    }

    this.orbitPhotonPoints = vectors;
    const photonGeo = new THREE.BufferGeometry();
    const photonPos = new Float32Array(5 * 3);
    photonGeo.setAttribute('position', new THREE.BufferAttribute(photonPos, 3));

    const photonMat = new THREE.PointsMaterial({
      color: 0x00ff99,
      size: 0.32,
      transparent: true,
      opacity: 0.95,
      blending: THREE.AdditiveBlending
    });

    this.orbitPhotonParticles = new THREE.Points(photonGeo, photonMat);
    this.orbitPhotonParticles.userData = { progress: [0, 0.2, 0.4, 0.6, 0.8] };
    this.orbitPhotonParticles.visible = this.showDirectionVectors;
    this.scene.add(this.orbitPhotonParticles);
  }

  animateOrbitPhotons() {
    if (!this.orbitPhotonParticles || !this.orbitPhotonPoints.length) return;
    this.orbitPhotonParticles.visible = this.showDirectionVectors;

    const progressArr = this.orbitPhotonParticles.userData.progress;
    const positions = this.orbitPhotonParticles.geometry.attributes.position.array;
    const totalPoints = this.orbitPhotonPoints.length;

    for (let i = 0; i < progressArr.length; i++) {
      progressArr[i] = (progressArr[i] + 0.005) % 1.0;
      const idx = Math.floor(progressArr[i] * (totalPoints - 1));
      const pt = this.orbitPhotonPoints[idx];

      if (pt) {
        positions[i * 3] = pt.x;
        positions[i * 3 + 1] = pt.y;
        positions[i * 3 + 2] = pt.z;
      }
    }
    this.orbitPhotonParticles.geometry.attributes.position.needsUpdate = true;
  }

  clearOrbitLine() {
    if (this.selectedOrbitLine) {
      this.scene.remove(this.selectedOrbitLine);
      this.selectedOrbitLine = null;
    }
    if (this.threatOrbitLine) {
      this.scene.remove(this.threatOrbitLine);
      this.threatOrbitLine = null;
    }
    if (this.orbitPhotonParticles) {
      this.scene.remove(this.orbitPhotonParticles);
      this.orbitPhotonParticles = null;
    }
    this.hideConjunctionLaser();
  }

  showConjunctionLaser(posA, posB) {
    if (!this.conjunctionLaserLine) return;
    const positions = new Float32Array([
      posA.x, posA.y, posA.z,
      posB.x, posB.y, posB.z
    ]);
    this.conjunctionLaserLine.geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    this.conjunctionLaserLine.geometry.attributes.position.needsUpdate = true;
    this.conjunctionLaserLine.visible = true;

    const midX = (posA.x + posB.x) / 2;
    const midY = (posA.y + posB.y) / 2;
    const midZ = (posA.z + posB.z) / 2;
    this.conjunctionSphereMesh.position.set(midX, midY, midZ);
    this.conjunctionSphereMesh.visible = true;
  }

  hideConjunctionLaser() {
    if (this.conjunctionLaserLine) this.conjunctionLaserLine.visible = false;
    if (this.conjunctionSphereMesh) this.conjunctionSphereMesh.visible = false;
  }

  focusConjunctionPair(targetObj, threatObj, intersectionPos) {
    if (!this.controls) return;
    this.isTracking = false;

    const pos = intersectionPos || { x: 0, y: 5.65, z: 0 };
    if (this.conjunctionSphereMesh) {
      this.conjunctionSphereMesh.position.set(pos.x, pos.y, pos.z);
      this.conjunctionSphereMesh.visible = true;
    }

    // Smoothly fly camera to vantage point looking at the hazard intersection node
    const distanceToOrigin = Math.sqrt(pos.x * pos.x + pos.y * pos.y + pos.z * pos.z) || 5.5;
    const normX = pos.x / distanceToOrigin;
    const normY = pos.y / distanceToOrigin;
    const normZ = pos.z / distanceToOrigin;

    this.camera.position.set(pos.x + normX * 4.5, pos.y + normY * 4.5 + 2.0, pos.z + normZ * 4.5);
    this.controls.target.set(pos.x, pos.y, pos.z);

    // Render threat orbit line
    if (threatObj) {
      this.renderThreatOrbit(threatObj);
    }
    if (targetObj) {
      this.renderSelectedOrbit(targetObj);
    }
  }

  triggerCollisionExplosion(pos) {
    audio.playExplosion();

    const explosionGroup = new THREE.Group();
    explosionGroup.position.set(pos.x, pos.y, pos.z);
    this.scene.add(explosionGroup);

    const fireGeo = new THREE.SphereGeometry(0.35, 16, 16);
    const fireMat = new THREE.MeshBasicMaterial({
      color: 0xff9900,
      transparent: true,
      opacity: 0.95,
      blending: THREE.AdditiveBlending
    });
    const fireMesh = new THREE.Mesh(fireGeo, fireMat);
    explosionGroup.add(fireMesh);

    const shockGeo = new THREE.RingGeometry(0.12, 0.28, 32);
    const shockMat = new THREE.MeshBasicMaterial({
      color: 0xff2a5f,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending
    });
    const shockMesh = new THREE.Mesh(shockGeo, shockMat);
    shockMesh.lookAt(this.camera.position);
    explosionGroup.add(shockMesh);

    const sparkCount = 220;
    const sparkGeo = new THREE.BufferGeometry();
    const sparkPositions = new Float32Array(sparkCount * 3);
    const sparkVelocities = [];

    for (let i = 0; i < sparkCount; i++) {
      sparkPositions[i * 3] = 0;
      sparkPositions[i * 3 + 1] = 0;
      sparkPositions[i * 3 + 2] = 0;

      const speed = 0.08 + Math.random() * 0.18;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);
      sparkVelocities.push(new THREE.Vector3(
        speed * Math.sin(phi) * Math.cos(theta),
        speed * Math.sin(phi) * Math.sin(theta),
        speed * Math.cos(phi)
      ));
    }

    sparkGeo.setAttribute('position', new THREE.BufferAttribute(sparkPositions, 3));
    const sparkMat = new THREE.PointsMaterial({
      color: 0xff4400,
      size: 0.18,
      transparent: true,
      opacity: 1.0,
      blending: THREE.AdditiveBlending
    });
    const sparkPoints = new THREE.Points(sparkGeo, sparkMat);
    explosionGroup.add(sparkPoints);

    this.activeExplosions.push({
      group: explosionGroup,
      fireMesh,
      shockMesh,
      sparkPoints,
      sparkVelocities,
      age: 0,
      maxAge: 80
    });
  }

  updateExplosions() {
    for (let i = this.activeExplosions.length - 1; i >= 0; i--) {
      const exp = this.activeExplosions[i];
      exp.age++;

      const progress = exp.age / exp.maxAge;

      const s = 1.0 + progress * 5.0;
      exp.fireMesh.scale.set(s, s, s);
      exp.fireMesh.material.opacity = Math.max(0, 1.0 - progress);

      const ringScale = 1.0 + progress * 9.0;
      exp.shockMesh.scale.set(ringScale, ringScale, ringScale);
      exp.shockMesh.material.opacity = Math.max(0, 1.0 - progress * 1.2);

      const pos = exp.sparkPoints.geometry.attributes.position.array;
      for (let j = 0; j < exp.sparkVelocities.length; j++) {
        pos[j * 3] += exp.sparkVelocities[j].x;
        pos[j * 3 + 1] += exp.sparkVelocities[j].y;
        pos[j * 3 + 2] += exp.sparkVelocities[j].z;
      }
      exp.sparkPoints.geometry.attributes.position.needsUpdate = true;
      exp.sparkPoints.material.opacity = Math.max(0, 1.0 - progress);

      if (exp.age >= exp.maxAge) {
        this.scene.remove(exp.group);
        this.activeExplosions.splice(i, 1);
      }
    }
  }

  triggerReentryPlasma(pos) {
    const spark = new THREE.Mesh(
      new THREE.SphereGeometry(0.12, 8, 8),
      new THREE.MeshBasicMaterial({ color: 0xff3b00, blending: THREE.AdditiveBlending })
    );
    spark.position.set(pos.x + (Math.random() - 0.5) * 0.1, pos.y + (Math.random() - 0.5) * 0.1, pos.z + (Math.random() - 0.5) * 0.1);
    this.reentryFireballGroup.add(spark);

    setTimeout(() => {
      this.reentryFireballGroup.remove(spark);
    }, 350);
  }

  onPointerDown(event) {
    if (event.button !== 0) return;

    const rect = this.renderer.domElement.getBoundingClientRect();
    this.mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.mouse, this.camera);

    // Collect all clickable objects: detailed meshes, instanced debris, and Moon
    const checkTargets = [...this.objectMeshes];
    if (this.instancedDebris) checkTargets.push(this.instancedDebris);
    if (this.moonMesh) checkTargets.push(this.moonMesh);

    const intersects = this.raycaster.intersectObjects(checkTargets, true);

    if (intersects.length > 0) {
      const hit = intersects[0];

      // 1. Check if hit is the Moon
      if (hit.object === this.moonMesh || (hit.object.userData && hit.object.userData.isMoon)) {
        this.selectMoon();
        return;
      }

      // 2. Check if hit is Instanced Debris
      if (hit.object === this.instancedDebris && hit.instanceId !== undefined) {
        const debrisObj = this.ambientObjects[hit.instanceId];
        if (debrisObj) {
          this.selectObject(debrisObj);
          audio.playDebrisTumblePing();
          return;
        }
      }

      // 3. Check if hit is an individual 3D Mesh (Satellites, Rockets, Debris)
      let topHit = hit.object;
      while (topHit.parent && !topHit.userData.obj && topHit.parent !== this.scene) {
        topHit = topHit.parent;
      }
      if (topHit.userData && topHit.userData.obj) {
        this.selectObject(topHit.userData.obj);
        audio.playObjectSound(topHit.userData.obj);
      }
    }
  }

  setCameraPreset(presetName) {
    if (!this.controls) return;
    this.isTracking = false;

    switch (presetName) {
      case 'default':
        this.controls.target.set(0, 0, 0);
        this.camera.position.set(0, 8, 18);
        break;
      case 'north_pole':
        this.controls.target.set(0, 0, 0);
        this.camera.position.set(0, 22, 0.1);
        break;
      case 'equator':
        this.controls.target.set(0, 0, 0);
        this.camera.position.set(20, 0, 0);
        break;
      case 'geo':
        this.controls.target.set(0, 0, 0);
        this.camera.position.set(0, 15, 45);
        break;
      case 'moon':
        if (this.moonMesh) {
          const mp = this.moonMesh.position;
          this.controls.target.set(mp.x, mp.y, mp.z);
          this.camera.position.set(mp.x + 3.5, mp.y + 1.8, mp.z + 5.0);
          this.selectMoon();
        }
        break;
      case 'follow':
        this.isTracking = true;
        break;
    }
  }

  shakeCamera(intensity = 0.35, durationMs = 700) {
    const startTime = performance.now();
    const baseTarget = this.controls ? this.controls.target.clone() : new THREE.Vector3();
    
    const applyShake = () => {
      const elapsed = performance.now() - startTime;
      if (elapsed < durationMs) {
        const decay = 1.0 - (elapsed / durationMs);
        const ox = (Math.random() - 0.5) * intensity * decay;
        const oy = (Math.random() - 0.5) * intensity * decay;
        const oz = (Math.random() - 0.5) * intensity * decay;
        this.camera.position.add(new THREE.Vector3(ox, oy, oz));
        if (this.controls) {
          this.controls.target.set(baseTarget.x + ox * 0.5, baseTarget.y + oy * 0.5, baseTarget.z + oz * 0.5);
        }
        requestAnimationFrame(applyShake);
      } else {
        if (this.controls) this.controls.target.copy(baseTarget);
      }
    };
    applyShake();
  }

  onWindowResize() {
    if (!this.container || !this.renderer || !this.camera) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  render() {
    if (this.controls) {
      this.controls.update();
    }
    // Update GPU twinkling stars uniform
    if (this.starMaterial && this.starMaterial.uniforms && this.starMaterial.uniforms.uTime) {
      this.starMaterial.uniforms.uTime.value = performance.now() * 0.0022;
    }
    // Pulsate major landmark stars
    if (this.brightStarsMat) {
      this.brightStarsMat.opacity = 0.82 + 0.18 * Math.sin(performance.now() * 0.0035);
    }
    // Slow celestial rotation of cosmic deep field
    if (this.starGroup) {
      this.starGroup.rotation.y += 0.00004;
    }

    if (this.targetReticleMesh && this.targetReticleMesh.visible) {
      const scale = 1.0 + 0.12 * Math.sin(Date.now() * 0.006);
      this.targetReticleMesh.scale.set(scale, scale, scale);
    }
    if (this.conjunctionSphereMesh && this.conjunctionSphereMesh.visible) {
      const s = 1.0 + 0.25 * Math.sin(Date.now() * 0.009);
      this.conjunctionSphereMesh.scale.set(s, s, s);
      this.conjunctionSphereMesh.rotation.y += 0.02;
    }

    // Animate active satellite scanning sensor cones, ground swath rings, and strobe beacons
    const nowSec = performance.now() * 0.001;
    if (this.objectMeshes) {
      for (let i = 0; i < this.objectMeshes.length; i++) {
        const m = this.objectMeshes[i];
        if (m && m.userData && m.userData.isScanningSatellite) {
          if (m.userData.scanCone) {
            m.userData.scanCone.material.opacity = 0.18 + 0.12 * Math.sin(nowSec * 3.5 + i);
            m.userData.scanCone.rotation.z = Math.sin(nowSec * 1.5 + i) * 0.14;
          }
          if (m.userData.swathRing) {
            m.userData.swathRing.material.opacity = 0.35 + 0.25 * Math.sin(nowSec * 4.0 + i);
          }
          if (m.userData.strobeBeacon) {
            const isFlash = Math.sin(nowSec * 10.0 + i * 2.0) > 0.65;
            m.userData.strobeBeacon.scale.setScalar(isFlash ? 1.8 : 0.4);
            m.userData.strobeBeacon.visible = isFlash;
          }
        }
      }
    }

    // Update Chandrayaan-4 Lunar Landing Mission Simulator
    if (this.chandrayaanActive) {
      this.updateChandrayaanStep();
    }

    this.renderer.render(this.scene, this.camera);
  }
}
