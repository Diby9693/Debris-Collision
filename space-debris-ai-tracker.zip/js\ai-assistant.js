/**
 * AEROSPACE AI VOICE & TEXT MISSION COPILOT (AstroBot)
 * High-Fidelity Natural Voice Synthesis + Speech Recognition
 * Comprehensive Project Knowledge Base & Academic Student Viva Guide
 * Multilingual Support: Hindi, Hinglish, English
 */

import { audio } from './audio-fx.js';

export class AIAssistant {
  constructor(app) {
    this.app = app;
    this.isListening = false;
    this.speechSynthesis = window.speechSynthesis;
    this.availableVoices = [];
    this.selectedVoice = null;
    this.voiceLanguage = 'hi-IN'; // Default to Indian English / Hindi natural voice
    this.history = [];

    // DOM Elements
    this.container = document.getElementById('ai-copilot-container');
    this.messagesContainer = document.getElementById('ai-copilot-messages');
    this.inputField = document.getElementById('ai-copilot-input');
    this.btnSend = document.getElementById('btn-ai-send');
    this.btnMic = document.getElementById('btn-ai-mic');
    this.btnClose = document.getElementById('btn-close-ai');
    this.btnMinimize = document.getElementById('btn-minimize-ai');

    // Initialize Voice & Speech Engine
    this.initVoiceSelection();
    this.initSpeechRecognition();
    this.setupEventListeners();

    // Welcome Greeting with interactive suggestion chips
    this.sendGreeting();
  }

  // -------------------------------------------------------------
  // 1. Natural Human Vocal Selection & Audio Tuning
  // -------------------------------------------------------------
  initVoiceSelection() {
    if (!this.speechSynthesis) return;

    const loadVoices = () => {
      this.availableVoices = this.speechSynthesis.getVoices();
      if (!this.availableVoices || this.availableVoices.length === 0) return;

      // Priority 1: Natural Google Hindi or Microsoft Hemant/Kalpana (Hindi)
      const hindiVoice = this.availableVoices.find(v => 
        (v.lang.includes('hi') || v.name.includes('Hindi') || v.name.includes('हिन्दी')) &&
        (v.name.includes('Google') || v.name.includes('Natural') || v.name.includes('Microsoft'))
      );

      // Priority 2: Natural Indian English / UK English / US English (warm, crisp human tone)
      const indianEngVoice = this.availableVoices.find(v => 
        v.lang === 'en-IN' || v.name.includes('India') || v.name.includes('Ravi') || v.name.includes('Heera')
      );

      const naturalEngVoice = this.availableVoices.find(v => 
        (v.name.includes('Google') && v.lang.startsWith('en')) || 
        (v.name.includes('Natural') && v.lang.startsWith('en')) ||
        v.name.includes('David') || v.name.includes('George') || v.name.includes('Mark')
      );

      // Choose best vocal actor
      this.selectedVoice = hindiVoice || indianEngVoice || naturalEngVoice || this.availableVoices[0];
    };

    loadVoices();
    if (this.speechSynthesis.onvoiceschanged !== undefined) {
      this.speechSynthesis.onvoiceschanged = loadVoices;
    }
  }

  // -------------------------------------------------------------
  // 2. High Quality Speech Output
  // -------------------------------------------------------------
  speak(text) {
    if (!this.speechSynthesis) return;

    // Stop previous utterances cleanly
    this.speechSynthesis.cancel();

    // Clean text of markdown formatting (asterisks, hashtags, bullets) before speech
    const cleanSpokenText = text
      .replace(/[*#_`>~]/g, '')
      .replace(/\[([^\]]+)\]\([^\)]+\)/g, '$1')
      .replace(/\s+/g, ' ')
      .trim();

    if (!cleanSpokenText) return;

    const utterance = new SpeechSynthesisUtterance(cleanSpokenText);
    
    // Auto-detect language of response
    const hasHindiChars = /[\u0900-\u097F]/.test(cleanSpokenText);
    if (hasHindiChars && this.availableVoices.length > 0) {
      const hiVoice = this.availableVoices.find(v => v.lang.includes('hi') || v.name.includes('Hindi'));
      if (hiVoice) utterance.voice = hiVoice;
      utterance.lang = 'hi-IN';
    } else if (this.selectedVoice) {
      utterance.voice = this.selectedVoice;
      utterance.lang = this.selectedVoice.lang || 'en-US';
    }

    // Warm, realistic human cadence (rate: 1.0, pitch: 1.0)
    utterance.rate = 1.02;
    utterance.pitch = 1.0;
    utterance.volume = 1.0;

    // Play subtle radio chirp cue before commander speaks
    try {
      audio.playRadarPing();
    } catch (e) {}

    this.speechSynthesis.speak(utterance);
  }

  // -------------------------------------------------------------
  // 3. Speech Recognition (Mic Input)
  // -------------------------------------------------------------
  initSpeechRecognition() {
    const SpeechRec = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRec) {
      this.recognition = new SpeechRec();
      this.recognition.continuous = false;
      this.recognition.interimResults = false;
      this.recognition.lang = 'hi-IN'; // Understands Hindi, English, and Hinglish

      this.recognition.onstart = () => {
        this.isListening = true;
        if (this.btnMic) {
          this.btnMic.classList.add('recording');
          this.btnMic.textContent = '🛑';
          this.btnMic.title = 'Listening... Speak now';
        }
      };

      this.recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        if (this.inputField) this.inputField.value = transcript;
        this.handleUserSubmit(transcript);
      };

      this.recognition.onerror = () => {
        this.stopListening();
      };

      this.recognition.onend = () => {
        this.stopListening();
      };
    } else {
      if (this.btnMic) {
        this.btnMic.style.display = 'none';
      }
    }
  }

  toggleListening() {
    if (!this.recognition) return;
    if (this.isListening) {
      this.recognition.stop();
      this.stopListening();
    } else {
      try {
        this.recognition.start();
      } catch (e) {
        this.stopListening();
      }
    }
  }

  stopListening() {
    this.isListening = false;
    if (this.btnMic) {
      this.btnMic.classList.remove('recording');
      this.btnMic.textContent = '🎙️';
      this.btnMic.title = 'Speak Voice Command';
    }
  }

  // -------------------------------------------------------------
  // 4. UI Setup & Event Listeners
  // -------------------------------------------------------------
  setupEventListeners() {
    if (this.btnSend && this.inputField) {
      this.btnSend.addEventListener('click', () => {
        const val = this.inputField.value.trim();
        if (val) this.handleUserSubmit(val);
      });

      this.inputField.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          const val = this.inputField.value.trim();
          if (val) this.handleUserSubmit(val);
        }
      });
    }

    if (this.btnMic) {
      this.btnMic.addEventListener('click', () => this.toggleListening());
    }

    if (this.btnClose) {
      this.btnClose.addEventListener('click', () => this.closeWidget());
    }

    if (this.btnMinimize) {
      this.btnMinimize.addEventListener('click', () => this.toggleMinimize());
    }
  }

  toggleWidget(forceState = null) {
    if (!this.container) return;
    const isHidden = forceState !== null ? !forceState : this.container.classList.contains('hidden');
    if (isHidden) {
      this.container.classList.remove('hidden');
      if (this.inputField) setTimeout(() => this.inputField.focus(), 150);
    } else {
      this.container.classList.add('hidden');
    }
  }

  closeWidget() {
    if (this.container) this.container.classList.add('hidden');
    if (this.speechSynthesis) this.speechSynthesis.cancel();
  }

  toggleMinimize() {
    if (this.container) this.container.classList.toggle('minimized');
  }

  // -------------------------------------------------------------
  // 5. Chat History & Message Rendering
  // -------------------------------------------------------------
  addMessage(sender, text, chips = []) {
    if (!this.messagesContainer) return;

    const msgDiv = document.createElement('div');
    msgDiv.className = `ai-msg ${sender === 'user' ? 'ai-msg-user' : 'ai-msg-bot'}`;

    // Render formatted markdown paragraphs
    const formattedHtml = text
      .replace(/\n\n/g, '<br><br>')
      .replace(/\n/g, '<br>')
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      .replace(/`([^`]+)`/g, '<code style="background:rgba(0,240,255,0.15);padding:1px 4px;border-radius:3px;">$1</code>');

    msgDiv.innerHTML = formattedHtml;

    // Add optional clickable suggestion chips
    if (chips && chips.length > 0) {
      const chipsContainer = document.createElement('div');
      chipsContainer.style.cssText = 'display:flex;flex-wrap:wrap;gap:4px;margin-top:8px;';
      chips.forEach(chip => {
        const btn = document.createElement('button');
        btn.textContent = chip.label;
        btn.style.cssText = 'background:rgba(0,240,255,0.15);border:1px solid rgba(0,240,255,0.4);color:var(--color-cyan);border-radius:12px;padding:3px 8px;font-size:10px;cursor:pointer;transition:all 0.2s;';
        btn.onmouseover = () => btn.style.background = 'rgba(0,240,255,0.3)';
        btn.onmouseout = () => btn.style.background = 'rgba(0,240,255,0.15)';
        btn.onclick = () => this.handleUserSubmit(chip.query);
        chipsContainer.appendChild(btn);
      });
      msgDiv.appendChild(chipsContainer);
    }

    this.messagesContainer.appendChild(msgDiv);
    this.messagesContainer.scrollTop = this.messagesContainer.scrollHeight;
  }

  sendGreeting() {
    const greetingText = `🛰️ **Namaste Commander!** Main AstroBot hoon — aapka AI Space Debris & Orbital Defense Copilot.
Main aapko is web application ke saare features, scientific principles, aur ab tak fix hui saari problems ke baare me sab kuch detail me bata sakta hoon.

Aap mujhse Hindi, Hinglish, ya English me pooch sakte hain, ya niche diye gaye quick topics par tap kar sakte hain:`;

    const chips = [
      { label: '❓ Project Problems & Fixes', query: 'app me kya problems thi aur kaise fix hui' },
      { label: '🎓 Student Viva Pitch', query: 'student presentation aur viva ke liye explain karo' },
      { label: '🚀 Chandrayaan-4 Launch', query: 'chandrayaan 4 mission start karo' },
      { label: '💥 Simulate Collision', query: 'collision impact simulate karo' },
      { label: '🌓 Toggle Theme', query: 'light mode on karo' }
    ];

    this.addMessage('bot', greetingText, chips);
  }

  // -------------------------------------------------------------
  // 6. Comprehensive Knowledge Base & Intent Resolution
  // -------------------------------------------------------------
  handleUserSubmit(query) {
    if (!query) return;
    this.addMessage('user', query);
    if (this.inputField) this.inputField.value = '';

    const q = query.toLowerCase().trim();

    // 1. Direct App Hardware & Simulation Actions
    if (q.includes('collision') || q.includes('takkar') || q.includes('impact') || q.includes('crash')) {
      this.app.ui.simulateForecastImpact(0);
      const reply = "🚨 Emergency collision alert trigger kar diya gaya hai! Tactical alert card top-right me open ho gaya hai aur 3D Earth par fragment breakup aur shockwave render ho raha hai.";
      this.addMessage('bot', reply);
      this.speak("Emergency collision alert triggered! Inspecting debris breakup on radar.");
      return;
    }

    if (q.includes('chandrayaan') || q.includes('moon') || q.includes('lunar') || q.includes('vikram') || q.includes('pragyan')) {
      this.app.ui.launchChandrayaanMission();
      const reply = "🚀 ISRO Chandrayaan-4 Lunar Landing Mission initialize ho gaya hai! LVM3 rocket liftoff, S200 booster jettison aur Vikram lander powered descent lunar south pole par shuru ho chuka hai.";
      this.addMessage('bot', reply);
      this.speak("Chandrayaan-4 mission launched! Commencing powered descent to lunar south pole.");
      return;
    }

    if (q.includes('light mode') || q.includes('light theme') || q.includes('din mode') || q.includes('white theme')) {
      if (!document.body.classList.contains('theme-light')) this.app.ui.toggleTheme();
      const reply = "☀️ Aerospace Operations Light Mode activate kar diya gaya hai!";
      this.addMessage('bot', reply);
      this.speak("Switched to Aerospace Operations Light Mode.");
      return;
    }

    if (q.includes('dark mode') || q.includes('dark theme') || q.includes('night mode') || q.includes('black theme')) {
      if (document.body.classList.contains('theme-light')) this.app.ui.toggleTheme();
      const reply = "🌙 Deep Space Cyberpunk Dark Mode activate kar diya gaya hai!";
      this.addMessage('bot', reply);
      this.speak("Switched to Deep Space Cyberpunk Dark Mode.");
      return;
    }

    if (q.includes('hide') || q.includes('sidebar') || q.includes('toggle pane') || q.includes('fullscreen') || q.includes('chupao')) {
      this.app.ui.toggleLeftPanel();
      this.app.ui.toggleRightPanel();
      const reply = "◧ Left aur Right auxiliary sidebars toggle ho gaye hain! Full unobstructed 3D Earth view ready hai. Aap '[' aur ']' keys se bhi toggle kar sakte hain.";
      this.addMessage('bot', reply);
      this.speak("Auxiliary sidebars toggled. Full Earth view active.");
      return;
    }

    // 2. Project Journey, Problems Discussed & How They Were Solved
    if (q.includes('problem') || q.includes('issue') || q.includes('history') || q.includes('kya fix kiya') || q.includes('kya kya problem')) {
      const reply = `🛠️ **Project Me Face Hui Problems & Unka Solution:**

1. **Blinking Stars**: Pehle stars gayab ho gaye the; unhe dynamic sinusoidal alpha shader se update kiya gaya jisse celestial stars natural tarike se twinkle/blink karte hain.
2. **View Source Code in Backend**: Source code ko front UI se hata kar cursor-click inspector me move kiya taaki clicking par clean modal me code dikhe.
3. **Collision Simulation**: Pehle object select karne par collision trigger nahi ho raha tha; exact ECI coordinate collision check aur kinetic explosion physics add ki.
4. **Netlify Earth Black Screen & Broken Buttons**: WebGL viewport container 0px render ho raha tha aur event listeners freeze the; container size auto-detection aur robust DOM event delegation se fix kiya.
5. **Panel Sliding & Buttons Unresponsive**: CSS flex z-index aur pointer-events fix kiye gaye taaki sliding drawers smooth behave karein.
6. **Real Audio Effects**: Artificial beeps ke badle real user MP3 sounds integrate kiye — debris break, spacecraft radar ping aur emergency siren.
7. **Auxiliary Sidebars**: Left (Catalog) aur Right (Telemetry) panels ko collapsible banaya handles aur hotkeys ke sath.
8. **Realistic Debris Material**: Hot-pink color hata kar realistic space scrap (weathered titanium, gold MLI foil, charred carbon composite) banaya.
9. **100% Accurate Timetable**: 14 time horizons me live ticking countdowns banaye jo 0 par aane ke baad auto-recycle hote hain.
10. **Tactical Alert Pop-up**: Central blocking modal ke badle sleek top-right toast alert banaya taaki 3D Earth explosion kabhi chhipe nahi!`;

      this.addMessage('bot', reply, [
        { label: '🎓 Student Viva Guide', query: 'student presentation aur viva ke liye explain karo' },
        { label: '💥 Test Collision', query: 'collision impact simulate karo' }
      ]);
      this.speak("Yahan project ki saari problems aur unke solutions ki complete details di gayi hain.");
      return;
    }

    // 3. Student Presentation, Viva Pitch & Conversation Starter/Ender
    if (q.includes('student') || q.includes('viva') || q.includes('presentation') || q.includes('teacher') || q.includes('judge') || q.includes('explain project')) {
      const reply = `🎓 **Student Project Presentation & Viva Guide:**

• **Project Title**: AI-Powered Space Debris Tracking & Conjunction Risk Assessment System.
• **1-Minute Elevator Pitch**:
"Respected Teachers & Judges, space me lakho broken debris fragments 28,000 km/h ki speed se ghoom rahe hain jo active satellites ke liye khatra hain. Humara system SGP4 Keplerian orbital propagation, Foster Collision Probability, aur Kinetic Energy calculation ($E_k = \\frac{1}{2}mv^2$) use karke 1 ghante se 1 saal tak ki prospective collisions ko real-time detect karta hai."

• **Key Viva Questions & Answers:**
1. *Q: Kinetic Energy ka formula kya hai collision me?*
   **Ans**: $E_k = \\frac{1}{2} \\mu v_{rel}^2$, jahan $\\mu = \\frac{m_1 m_2}{m_1 + m_2}$ reduced mass hai.
2. *Q: Kessler Syndrome kya hota hai?*
   **Ans**: Jab ek collision se hazaro naye fragments bante hain jo doosre satellites se takrakar cascading chain reaction paida karte hain.
3. *Q: Time horizons kaise calculate hote hain?*
   **Ans**: 14 discrete horizons (1H to 1Y) me orbital state vectors propagate kiye jaate hain aur miss distance compare hota hai.

• **How to Start & End Conversation with Evaluators:**
- *Start*: "Good morning Sir/Ma'am! Today we present our Autonomous Aerospace Defense Copilot."
- *Demo Flow*: Show 3D Earth -> Select Cartosat-2C -> Show Scanning Sensor Cone -> Simulate Conjunction -> Launch Chandrayaan-4.
- *End*: "Thank you for your valuable time and feedback! We are open to questions."`;

      this.addMessage('bot', reply, [
        { label: '📐 Physics & Math Details', query: 'physics aur formulas explain karo' },
        { label: '🚀 Launch Chandrayaan-4', query: 'chandrayaan 4 launch karo' }
      ]);
      this.speak("Aapki student presentation aur viva ke liye complete script aur scientific answers ready hain.");
      return;
    }

    // 4. Physics & Orbital Mechanics Explanations
    if (q.includes('physics') || q.includes('formula') || q.includes('math') || q.includes('kepler') || q.includes('foster') || q.includes('sgp4')) {
      const reply = `📐 **Core Physics & Mathematics in this System:**

1. **Keplerian Orbital Elements**:
   - $a$ (Semi-major axis): Orbit ka size.
   - $e$ (Eccentricity): Orbit ki circularity vs ellipticity.
   - $i$ (Inclination): Earth ke equator se tilt angle.
   - $\\Omega$ (RAAN), $\\omega$ (Argument of Perigee), $M$ (Mean Anomaly).

2. **Kepler's Equation Solver**:
   $M = E - e \\sin(E)$ (Newton-Raphson iterative method se eccentric anomaly solve hota hai).

3. **Foster 2D Collision Probability**:
   $P_c = \\exp\\left(-\\frac{1}{2} \\frac{d^2}{\\sigma^2}\\right) \\cdot \\left(\\frac{R_{comb}}{\\sigma}\\right)^2$

4. **Relative Kinetic Impact Energy**:
   $E_k = \\frac{1}{2} \\frac{m_1 m_2}{m_1 + m_2} v_{rel}^2$ (Typical hypervelocity impact generates 10 to 50 Gigajoules of kinetic energy).`;

      this.addMessage('bot', reply);
      this.speak("Keplerian orbital mechanics aur Foster collision probability ke mathematical formulas yahan documented hain.");
      return;
    }

    // 5. Basic Polite Greetings & Social Flow (Hello, How to Start, Goodbye)
    if (q.includes('hi') || q.includes('hello') || q.includes('hey') || q.includes('namaste') || q.includes('kaise ho')) {
      const reply = "👋 Hello Commander! Main bilkul ready hoon. Aap space debris track kar sakte hain, satellite scan light inspect kar sakte hain, ya Chandrayaan-4 mission launch kar sakte hain. Aap kya explore karna chahte hain?";
      this.addMessage('bot', reply, [
        { label: '🚀 Chandrayaan-4', query: 'chandrayaan 4 mission start karo' },
        { label: '💥 Simulate Impact', query: 'collision impact simulate karo' },
        { label: '❓ Project Problems', query: 'app me kya problems thi aur kaise fix hui' }
      ]);
      this.speak("Hello Commander! Mission control is active and ready for your commands.");
      return;
    }

    if (q.includes('bye') || q.includes('alvida') || q.includes('thank') || q.includes('shukriya') || q.includes('dhanyawad') || q.includes('end')) {
      const reply = "🛰️ You're most welcome Commander! Agar koi aur query ho ya viva preparation me help chahiye ho toh mujhe call kijiyega. AstroBot signing off!";
      this.addMessage('bot', reply);
      this.speak("You're welcome Commander! AstroBot signing off. Have a great mission!");
      return;
    }

    // 6. Default Fallback with Helpful Guidance
    const fallback = `🤖 **AstroBot Mission Intelligence:**
Main aapki query ("${query}") samajh gaya hoon. Main niche diye gaye tasks instantly perform kar sakta hoon:
1. **Simulation Actions**: 'Collision dikhao', 'Chandrayaan launch karo', 'Light mode on karo', 'Sidebars toggle karo'.
2. **Project History**: 'App me kya kya problem fix hui?'.
3. **Student & Viva Prep**: 'Student presentation guide', 'Physics formulas explain karo'.`;

    this.addMessage('bot', fallback, [
      { label: '❓ Project Fixes', query: 'app me kya problems thi aur kaise fix hui' },
      { label: '🎓 Student Viva Guide', query: 'student presentation aur viva ke liye explain karo' },
      { label: '🚀 Chandrayaan-4', query: 'chandrayaan 4 launch karo' },
      { label: '💥 Simulate Collision', query: 'collision impact simulate karo' }
    ]);
    this.speak("I have processed your query Commander. You can select one of the quick options or ask any question.");
  }
}
